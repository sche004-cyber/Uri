"""Phase 2 closure: controlled power-loss qualification harness for the supervisor ledger
(implements `docs/plans/PHASE2A_POWER_LOSS_TEST_PLAN.md`; procedure in `PHASE2CLOSE_PHYSICAL_ACCEPTANCE_RUNBOOK.md`).

The durability claim (WAL + synchronous=FULL survives power loss) can only be QUALIFIED on a machine whose power is
really cut: a throwaway VM powered off by its hypervisor. Killing a process cannot qualify it (the OS page cache
survives a process kill). This harness therefore has four roles:

  guest     runs INSIDE the VM at every boot: first `verify` (report the ledger left by the previous boot to the host),
            then an endless REAL supervisor workload (submit -> admit -> declare intents -> run a real attempt of the
            fake NDJSON executor writing a local file). After each supervisor call RETURNS (= its transaction committed)
            it sends an acknowledgement to the host over TCP. Acks never touch the guest disk.
  host      runs OUTSIDE the VM: records every ack to its own disk (fsync per line), powers the VM off with the
            hypervisor at a random instant, powers it on, waits for the guest's verify report, and compares: every
            acknowledged step must be present after the power cut. Repeats N iterations, then writes a verdict.
  verify    the checks, also callable alone on a ledger file: (a) acknowledged steps present (host side), (b) PRAGMA
            integrity_check == ok, (c) no attempt SPAWNING/RUNNING without its admission and intents, (d) startup
            recovery leaves no task RUNNING/RECOVERING, (e) recovery never relaunches anything (no attempt in the
            verification epoch for a task from an earlier boot).
  simulate  LOCAL PLUMBING CHECK ONLY: the same host logic with "power off" = kill of a local guest process. Its
            result is labelled SIMULATED and can never qualify durability (see above).

Control: `guest --synchronous NORMAL` weakens the ledger for a negative-control series. The plan's pass criterion
needs the control series to LOSE at least one acknowledged commit; otherwise the rig is not strong enough and a FULL
result means nothing.

Usage (VM):    python scripts/phase2close_powerloss_harness.py guest --ledger D:\\pl\\ledger.db --host 10.0.0.1 --port 47710
Usage (host):  python scripts/phase2close_powerloss_harness.py host --port 47710 --iterations 200 --out <dir>
                   --power-off "powershell -NoProfile -Command Stop-VM -Name URI-PL -TurnOff -Force"
                   --power-on  "powershell -NoProfile -Command Start-VM -Name URI-PL"
Usage (local): python scripts/phase2close_powerloss_harness.py simulate --iterations 10 --out <dir>
"""
from __future__ import annotations

import argparse
import json
import os
import random
import socket
import sqlite3
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

STEPS = ("submitted", "admitted", "intents", "ended")
RANK = {s: i for i, s in enumerate(STEPS)}
FAKE = ROOT / "tests" / "phase2a" / "helpers" / "fake_executor.py"


# ---------------------------------------------------------------------------------------------- verification (pure)
def ledger_facts(ledger_path, boot_prefix=None):
    """Read-only facts of a ledger file: integrity, per-task highest durable step, attempts in flight."""
    db = sqlite3.connect(f"file:{ledger_path}?mode=ro", uri=True)
    try:
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
        like = (boot_prefix or "") + "%"
        tasks = {r[0]: r[1] for r in db.execute("SELECT task_id, state FROM task WHERE task_id LIKE ?", (like,))}
        steps = {t: "submitted" for t in tasks}
        for (t,) in db.execute("SELECT DISTINCT task_id FROM admission WHERE task_id LIKE ?", (like,)):
            steps[t] = "admitted"
        for (t,) in db.execute("SELECT DISTINCT task_id FROM effect_intent WHERE task_id LIKE ?", (like,)):
            steps[t] = "intents"
        for (t,) in db.execute("SELECT DISTINCT task_id FROM attempt WHERE status IN ('ENDED','FENCED') AND task_id LIKE ?", (like,)):
            steps[t] = "ended"
        orphans = []
        for aid, t, st in db.execute("SELECT attempt_id, task_id, status FROM attempt WHERE status IN ('SPAWNING','RUNNING')"):
            has_adm = db.execute("SELECT 1 FROM admission WHERE attempt_id=?", (aid,)).fetchone() is not None
            has_int = db.execute("SELECT 1 FROM effect_intent WHERE attempt_id=?", (aid,)).fetchone() is not None
            if not (has_adm and has_int):
                orphans.append({"attempt_id": aid, "task_id": t, "status": st, "admission": has_adm, "intents": has_int})
        in_flight = [r[0] for r in db.execute("SELECT task_id FROM task WHERE state IN ('RUNNING','RECOVERING')")]
        return {"integrity": integrity, "tasks": tasks, "steps": steps, "orphan_attempts": orphans, "in_flight_before_recovery": in_flight}
    finally:
        db.close()


def compare(acked: dict, present: dict) -> list:
    """acked/present: task_id -> highest step. Returns every acknowledged step that is missing after the cut."""
    lost = []
    for task, step in sorted(acked.items()):
        have = present.get(task)
        if have is None or RANK[have] < RANK[step]:
            lost.append({"task_id": task, "acked": step, "present": have})
    return lost


def verify(ledger_path, boot_prefix=None, recover=True):
    """Full guest-side verification of the ledger left by the previous boot (prefix = that boot's task-id prefix)."""
    if not Path(ledger_path).is_file():
        return {"ledger": "ABSENT"}
    facts = ledger_facts(ledger_path, boot_prefix)
    out = {"integrity": facts["integrity"], "steps": facts["steps"], "orphan_attempts": facts["orphan_attempts"],
           "in_flight_before_recovery": facts["in_flight_before_recovery"]}
    if recover and facts["integrity"] == "ok":
        from uri_supervisor.supervisor import Supervisor
        sup = Supervisor(ledger_path, run_recovery=False)
        try:
            results = sup.recover_all()
            L = sup.ledger
            still = [r[0] for r in L.q("SELECT task_id FROM task WHERE state IN ('RUNNING','RECOVERING')")]
            relaunched = [r[0] for r in L.q("SELECT DISTINCT task_id FROM attempt WHERE epoch=? AND task_id NOT LIKE ?",
                                            (sup.epoch, "unused-%"))]
            out.update(recovery_decisions=len(results), still_in_flight=still, relaunched_by_recovery=relaunched,
                       durability=L.durability_report())
        finally:
            sup.close()
    out["invariants_ok"] = (out["integrity"] == "ok" and not out["orphan_attempts"]
                            and not out.get("still_in_flight") and not out.get("relaunched_by_recovery"))
    return out


# ---------------------------------------------------------------------------------------------- guest
class Acker:
    def __init__(self, host, port):
        self.sock = socket.create_connection((host, port), timeout=10)
        self.sock.settimeout(None)
        self.lock = threading.Lock()

    def send(self, obj):
        with self.lock:
            self.sock.sendall((json.dumps(obj, separators=(",", ":")) + "\n").encode())


def guest(a):
    ledger = Path(a.ledger)
    ledger.parent.mkdir(parents=True, exist_ok=True)
    counter = ledger.with_name("boot_counter.txt")
    previous = int(counter.read_text().strip()) if counter.exists() else 0
    boot = previous + 1
    with open(counter, "w") as fh:            # the boot number is written durably BEFORE any workload
        fh.write(str(boot))
        fh.flush()
        os.fsync(fh.fileno())
    ack = Acker(a.host, a.port)
    report = verify(str(ledger), boot_prefix=f"pl-b{previous}-") if previous else {"ledger": "FIRST_BOOT"}
    ack.send({"type": "report", "boot": boot, "previous_boot": previous, "synchronous": a.synchronous, "report": report})
    from uri_supervisor.executors import GENERIC_NDJSON
    from uri_supervisor.supervisor import Supervisor
    from dataclasses import replace
    sup = Supervisor(str(ledger))
    if a.synchronous == "NORMAL":               # negative control ONLY: weaken durability on purpose
        sup.ledger._db.execute("PRAGMA synchronous=NORMAL")
    if not sup.ledger.q("SELECT 1 FROM resource_pool WHERE name='slot'"):
        sup.registry.create_pool("slot", 1)
    if not sup.ledger.q("SELECT 1 FROM executor_registration WHERE executor_id='plfake'"):
        sup.registry.register_executor(replace(GENERIC_NDJSON, executor_id="plfake"), capabilities=("run",), claims={"slot": 1},
                                       quota_pools=(), preemptible=False, version="pl-1")
    ack.send({"type": "ready", "boot": boot, "durability": sup.ledger.durability_report()})
    work = ledger.parent / "work"
    work.mkdir(exist_ok=True)
    seq = 0
    while True:
        seq += 1
        tid = f"pl-b{boot}-{seq:06d}"
        target = work / f"{tid}.txt"
        sup.submit_task(tid, "powerloss", {"seq": seq}, authorization={"scope": {"workspace": str(work)}},
                        effects=[{"op_class": "local_write", "operation": "write", "target": str(target), "paths": [str(target)]}],
                        postconditions=[{"kind": "file_exists", "spec": {"path": str(target)}}],
                        requirements={"capabilities": ["run"]})
        ack.send({"type": "ack", "boot": boot, "task_id": tid, "step": "submitted"})
        adm = sup.admit_next(only_task_id=tid)
        if adm is None:
            ack.send({"type": "note", "boot": boot, "task_id": tid, "note": "NOT_ADMITTED"})
            continue
        ack.send({"type": "ack", "boot": boot, "task_id": tid, "step": "admitted"})
        sup.declare_intents(adm)
        ack.send({"type": "ack", "boot": boot, "task_id": tid, "step": "intents"})
        sup.run_attempt(adm, cwd=str(work), resolved_executable=sys.executable,
                        extra_argv=[str(FAKE), "--scenario", "ok_write", "--path", str(target), "--content", tid],
                        timeout_s=60, inactivity_s=30)
        ack.send({"type": "ack", "boot": boot, "task_id": tid, "step": "ended"})


# ---------------------------------------------------------------------------------------------- host
class AckLog:
    """Host-side record of every guest message: append + fsync per line, so the host's own crash loses nothing."""

    def __init__(self, path):
        self.path = Path(path)
        self.fh = open(self.path, "a", encoding="utf-8")
        self.lock = threading.Lock()
        self.reports = {}
        self.ready = {}
        self.acked = {}          # boot -> {task_id: highest step}

    def add(self, msg):
        with self.lock:
            self.fh.write(json.dumps(msg, separators=(",", ":")) + "\n")
            self.fh.flush()
            os.fsync(self.fh.fileno())
            t = msg.get("type")
            if t == "ack":
                cur = self.acked.setdefault(msg["boot"], {})
                if RANK[msg["step"]] >= RANK.get(cur.get(msg["task_id"]), -1):
                    cur[msg["task_id"]] = msg["step"]
            elif t == "report":
                self.reports[msg["boot"]] = msg
            elif t == "ready":
                self.ready[msg["boot"]] = msg


def serve(port, log: AckLog):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0" if port else "127.0.0.1", port))
    srv.listen(8)

    def client(conn):
        buf = b""
        with conn:
            while True:
                try:
                    chunk = conn.recv(65536)
                except OSError:
                    return
                if not chunk:
                    return
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    try:
                        log.add(json.loads(line))
                    except ValueError:
                        pass

    def loop():
        while True:
            try:
                conn, _ = srv.accept()
            except OSError:
                return
            threading.Thread(target=client, args=(conn,), daemon=True).start()
    threading.Thread(target=loop, daemon=True).start()
    return srv


def wait_for(pred, timeout):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if pred():
            return True
        time.sleep(0.2)
    return False


def campaign(out, iterations, power_off, power_on, min_s, max_s, boot_timeout, port, label):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    log = AckLog(out / "acks.jsonl")
    srv = serve(port, log)
    port = srv.getsockname()[1]
    rows, rng = [], random.Random()
    try:
        power_on(port)
        if not wait_for(lambda: 1 in log.ready, boot_timeout):
            raise SystemExit("GUEST_NEVER_READY (boot 1)")
        for i in range(1, iterations + 1):
            boot = max(log.ready)
            delay = rng.uniform(min_s, max_s)
            time.sleep(delay)
            power_off()
            acked = dict(log.acked.get(boot, {}))
            power_on(port)
            if not wait_for(lambda: (boot + 1) in log.reports, boot_timeout):
                rows.append({"iteration": i, "boot": boot, "delay_s": round(delay, 3), "verdict": "NO_REPORT"})
                break
            rep = log.reports[boot + 1]["report"]
            lost = compare(acked, rep.get("steps") or {})
            ok = not lost and rep.get("invariants_ok") is True
            rows.append({"iteration": i, "boot": boot, "delay_s": round(delay, 3), "acked_tasks": len(acked),
                         "acked_ended": sum(1 for s in acked.values() if s == "ended"), "lost": lost,
                         "integrity": rep.get("integrity"), "orphans": len(rep.get("orphan_attempts") or []),
                         "still_in_flight": rep.get("still_in_flight"), "relaunched": rep.get("relaunched_by_recovery"),
                         "verdict": "PASS" if ok else "FAIL"})
            (out / "iterations.json").write_text(json.dumps(rows, indent=1), encoding="utf-8")
            if not wait_for(lambda: (boot + 1) in log.ready, boot_timeout):
                rows.append({"iteration": i + 1, "verdict": "GUEST_NEVER_READY"})
                break
    finally:
        try:
            power_off()
        except Exception:  # noqa: BLE001
            pass
        srv.close()
    sync = {m.get("synchronous") for m in log.reports.values()}
    summary = {"label": label, "iterations_requested": iterations, "iterations_run": len(rows),
               "passed": sum(1 for r in rows if r.get("verdict") == "PASS"),
               "failed": sum(1 for r in rows if r.get("verdict") != "PASS"),
               "lost_acknowledged_steps": sum(len(r.get("lost") or []) for r in rows),
               "synchronous": sorted(s for s in sync if s), "finished": time.strftime("%Y-%m-%dT%H:%M:%S")}
    summary["verdict"] = ("SIMULATED_ONLY_NOT_A_QUALIFICATION" if label == "SIMULATED" else
                          ("ALL_ITERATIONS_PASS" if summary["failed"] == 0 and summary["iterations_run"] == iterations else "FAIL"))
    (out / "summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    (out / "iterations.json").write_text(json.dumps(rows, indent=1), encoding="utf-8")
    print(json.dumps(summary, indent=1))
    return summary


def host(a):
    def power_off():
        subprocess.run(a.power_off, shell=True, check=False, stdin=subprocess.DEVNULL, timeout=120)

    def power_on(_port):
        subprocess.run(a.power_on, shell=True, check=False, stdin=subprocess.DEVNULL, timeout=300)
    s = campaign(a.out, a.iterations, power_off, power_on, a.min_s, a.max_s, a.boot_timeout, a.port, "PHYSICAL_VM")
    return 0 if s["verdict"] == "ALL_ITERATIONS_PASS" else 1


def simulate(a):
    """Process-kill stand-in for the hypervisor: proves the plumbing (acks, verify, compare, recovery) only."""
    from uri_supervisor import winproc
    out = Path(a.out)
    ledger = out / "guest" / "ledger.db"
    state = {"proc": None}

    def power_on(port):
        env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
        state["proc"] = subprocess.Popen([sys.executable, "-I", "-B", str(Path(__file__).resolve()), "guest", "--ledger", str(ledger),
                                          "--host", "127.0.0.1", "--port", str(port), "--synchronous", a.synchronous],
                                         cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                         stderr=open(out / "guest_stderr.txt", "ab"), env=env)

    def power_off():
        p = state["proc"]
        if p is not None and p.poll() is None:
            if winproc.IS_WINDOWS:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True, stdin=subprocess.DEVNULL)
            else:  # pragma: no cover
                p.kill()
            p.wait(30)
    s = campaign(out, a.iterations, power_off, power_on, a.min_s, a.max_s, a.boot_timeout, 0, "SIMULATED")
    return 0 if s["failed"] == 0 and s["iterations_run"] == a.iterations else 1


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="role", required=True)
    g = sub.add_parser("guest")
    g.add_argument("--ledger", required=True)
    g.add_argument("--host", required=True)
    g.add_argument("--port", type=int, required=True)
    g.add_argument("--synchronous", choices=("FULL", "NORMAL"), default="FULL")
    h = sub.add_parser("host")
    h.add_argument("--port", type=int, default=47710)
    h.add_argument("--iterations", type=int, default=200)
    h.add_argument("--out", required=True)
    h.add_argument("--power-off", required=True)
    h.add_argument("--power-on", required=True)
    h.add_argument("--min-s", type=float, default=2.0)
    h.add_argument("--max-s", type=float, default=20.0)
    h.add_argument("--boot-timeout", type=float, default=600.0)
    v = sub.add_parser("verify")
    v.add_argument("--ledger", required=True)
    v.add_argument("--prefix", default=None)
    v.add_argument("--no-recover", action="store_true")
    s = sub.add_parser("simulate")
    s.add_argument("--iterations", type=int, default=10)
    s.add_argument("--out", required=True)
    s.add_argument("--synchronous", choices=("FULL", "NORMAL"), default="FULL")
    s.add_argument("--min-s", type=float, default=1.0)
    s.add_argument("--max-s", type=float, default=4.0)
    s.add_argument("--boot-timeout", type=float, default=120.0)
    a = ap.parse_args()
    if a.role == "guest":
        return guest(a)
    if a.role == "host":
        return host(a)
    if a.role == "simulate":
        return simulate(a)
    print(json.dumps(verify(a.ledger, a.prefix, recover=not a.no_recover), indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
