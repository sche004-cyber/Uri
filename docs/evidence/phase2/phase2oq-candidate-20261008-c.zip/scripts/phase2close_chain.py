"""Phase 2 closure regression chain (2026-10-08). Runs every gate SEQUENTIALLY (the Phase 1 full suite rewrites part of
the source pin, so nothing runs concurrently) and writes one evidence directory. It never cuts a candidate itself; it
prints a summary and exits non-zero when any gate's outcome is not the expected one, so a candidate is only cut from a
green chain (lesson of review round 3: suite counts alone are not enough).

Gates, in order:
  1. phase2        python -I scripts/phase2d_regression.py phase2          (all Phase 2 suites, incl. tests/phase2ops)
  2. authority     ... authority                                           (Phase 1 authority suites; baseline 134)
  3. phase1-full   ... phase1-full                                         (baseline 2675 passed / 12 skipped / 11 failed)
                   Operational qualification (review round 1, OQ-R1-4): run with OLLAMA_BASE_URL pointed at an unreachable
                   port so a local Ollama service outside the tree cannot turn opt-in live tests on (the baseline ran with
                   no Ollama listening). Review round 2 (OQ-R2-1): PASS only when, per test, nothing regressed: the SAME
                   failure IDs; the SAME total; every skip (location + reason, URLs normalised) is one the baseline also
                   had, never more of one kind; and every baseline skip that disappeared is matched by a named PASSED test
                   of the same file (a live test that hard-codes 127.0.0.1:11434 passes while Ollama runs on this PC).
     2b. phase1-scope  no file the Phase 1 suite collects or imports changed since the accepted closure candidate -f:
                   every path that differs from -f (or is new / modified vs HEAD) lies in Phase 2-only scope, and nothing
                   outside that scope imports the Phase 2 packages or scripts.
  4. residue       removes ONLY the two zero-byte files the Phase 1 full suite plants at the tree root
  5. flutter       flutter test (whole uri_ui/test)
  6. bridge xN     scripts/phase2ops_validate_ui_bridge.py, N runs, + every CLIENT_REFUSAL line of each server log
  7. native        scripts/phase2ops_native_execution.py --provider codex_cli --model gpt-6-sol   (REAL Codex; optional)
  8. native-worker scripts/phase2oq_native_worker.py (operational qualification, EXE-1): REAL server + worker processes
                   with the NATIVE codex.exe (pinned launch chain, client-profile CODEX_HOME, Windows sandbox) against
                   the scripted local endpoint: the not-logged-in profile fails closed (W), no sandbox mode / the npm
                   launcher invalidate the record (W2, W3), and the worker-environment lifecycle reaches a verified
                   receipt and a mid-run cancel with no surviving process (L, auth gate substituted, not PA-10)

Usage: .venv/Scripts/python.exe -I scripts/phase2close_chain.py <evidence_dir> [--bridge-runs 10] [--no-native] [--only g1,g2]
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable
RESIDUE = ("STALE_BOOTSTRAP_EXECUTED", "STALE_LAZY_EXECUTED")


def run(cmd, log, cwd=ROOT, env=None, timeout=7200):
    t0 = time.time()
    with open(log, "wb") as fh:
        fh.write((" ".join(map(str, cmd)) + "\n").encode())
        fh.flush()
        try:
            r = subprocess.run(cmd, cwd=str(cwd), stdout=fh, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                               env=env, timeout=timeout)
            code = r.returncode
        except subprocess.TimeoutExpired:
            code = "TIMED_OUT"
        fh.write(f"\nEXIT={code} DURATION_S={round(time.time() - t0, 1)}\n".encode())
    return code


def pytest_counts(log):
    text = Path(log).read_text(encoding="utf-8", errors="replace")
    tail = [l for l in text.splitlines() if re.search(r"\d+ (passed|failed)", l)]
    line = tail[-1] if tail else ""
    get = lambda k: int(m.group(1)) if (m := re.search(r"(\d+) " + k, line)) else 0
    return {"passed": get("passed"), "failed": get("failed"), "skipped": get("skipped"), "errors": get("error"), "line": line.strip()}


def failed_ids(log):
    text = Path(log).read_text(encoding="utf-8", errors="replace")
    return sorted(set(m.strip() for m in re.findall(r"^FAILED (.+?)(?: - .*)?\r?$", text, re.M)))


SKIP_RE = re.compile(r"^SKIPPED \[(\d+)\] (\S+?):(\d+): (.*)$", re.M)


def skip_multiset(log):
    """{(file, line, reason with URLs/OS error detail normalised): count} from a `-rs` summary."""
    out = {}
    text = Path(log).read_text(encoding="utf-8", errors="replace")
    for n, loc, line, reason in SKIP_RE.findall(text):
        reason = re.sub(r"https?://\S+", "<URL>", reason)
        reason = re.sub(r"<URL>:? <urlopen error.*$", "<URL>", reason).strip()
        key = (loc.replace("\\", "/").split("/")[-1], line, reason)
        out[key] = out.get(key, 0) + int(n)
    return out


def passed_ids(log):
    text = Path(log).read_text(encoding="utf-8", errors="replace")
    return sorted(set(m.strip() for m in re.findall(r"^PASSED (.+?)\r?$", text, re.M)))


BASELINE_TOTAL = 2675 + 12 + 11


COLLECTION_BASELINE = ROOT.parent / "evidence" / "phase2oq" / "phase1_collection_baseline.txt"


def phase1_collection(log_path):
    """Test IDs the Phase 1 full scope collects (same ignores as the run), written to `log_path`. Sorted list."""
    run([PY, "-I", "scripts/phase2d_regression.py", "phase1-full", "--", "--collect-only"], log_path, timeout=1800,
        env={**os.environ, "OLLAMA_BASE_URL": "http://127.0.0.1:9"})
    text = Path(log_path).read_text(encoding="utf-8", errors="replace")
    return sorted(set(l.strip() for l in text.splitlines() if "::" in l and not l.startswith(("RUN", "ERROR", "FAILED"))))


def phase1_equivalence(log, baseline_log, counts, collected=None, baseline_collection=None):
    """OQ-R2-1: per-test non-regression of a Phase 1 full run against the baseline log. Returns (ok, details).
    `collected` / `baseline_collection` (test IDs): when given they must be identical, so a missing test can never be
    offset by a new one; every passed and failed ID must belong to the collection."""
    now, base = failed_ids(log), failed_ids(baseline_log)
    total = counts["passed"] + counts["skipped"] + counts["failed"] + counts["errors"]
    s_now, s_base = skip_multiset(log), skip_multiset(baseline_log)
    extra = {"|".join(k): v - s_base.get(k, 0) for k, v in s_now.items() if v > s_base.get(k, 0)}
    gone = {k: n - s_now.get(k, 0) for k, n in s_base.items() if n > s_now.get(k, 0)}
    passes = passed_ids(log)
    unmatched = {"|".join(k): n for k, n in gone.items()
                 if k[0] == "unittest.py" or sum(1 for pid in passes if pid.split("::")[0].split("/")[-1] == k[0]) < n}
    details = {"failed_ids": now, "SAME_FAILURE_SET": now == base, "total": total, "baseline_total": BASELINE_TOTAL,
               "skips_not_in_baseline": extra, "baseline_skips_gone": {"|".join(k): n for k, n in gone.items()},
               "gone_skips_without_named_pass": unmatched, "passed_ids_recorded": len(passes)}
    ok = (now == base and counts["errors"] == 0 and total == BASELINE_TOTAL and not extra and not unmatched
          and len(passes) == counts["passed"])
    if collected is not None or baseline_collection is not None:
        coll, bcoll = set(collected or ()), set(baseline_collection or ())
        missing, added = sorted(bcoll - coll), sorted(coll - bcoll)
        stray = sorted(t for t in passes + now if t not in coll)
        details.update(collection_size=len(coll), baseline_collection_size=len(bcoll), collection_missing=missing[:20],
                       collection_added=added[:20], results_outside_collection=stray[:20])
        ok = ok and not missing and not added and not stray and len(coll) == BASELINE_TOTAL
    return ok, details


PHASE2_SCOPE = ("tests/phase2", "uri_supervisor/", "uri_supervisor_bridge/", "uri_ui/", "docs/", "scripts/phase2",
                "scripts/run_uri_supervised_worker.py", "scripts/run_uri_phase2_server.py", "evidence/", "work/")


FROZEN_PHASE1 = Path(r"C:\Users\cheta\.codex\worktrees\uri-phase1-integration\uri-agent\work\c1\checkpoints\final-closure-20261005-phase1.zip")


def phase1_scope_check(root, closure_zip, frozen_zip=FROZEN_PHASE1):
    """OQ-R2-1: prove the Phase 1 suite's inputs equal those of the accepted closure candidate. Every path that differs
    from -f, is new, or is modified vs HEAD must be either Phase 2-only scope or a frozen Phase 1 checkpoint file whose
    bytes equal the checkpoint. Read-only git."""
    import hashlib
    import zipfile
    git = lambda *a: subprocess.run(["git", "-C", str(root), *a], capture_output=True, text=True).stdout.splitlines()
    manifest = json.loads(zipfile.ZipFile(closure_zip).read("MANIFEST.json"))
    changed = []
    for rel, digest in manifest.items():
        if rel.startswith("evidence/"):
            continue
        f = root / rel
        if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest() != digest:
            changed.append(rel)
    new = [r for r in git("ls-files", "-o", "--exclude-standard") if r not in manifest]
    modified = [r for r in git("diff", "--name-only", "HEAD") if r not in manifest]
    frozen = zipfile.ZipFile(frozen_zip)
    frozen_names = set(frozen.namelist())
    outside, frozen_ok = [], 0
    for r in sorted(set(changed + new + modified)):
        if r.startswith(PHASE2_SCOPE):
            continue
        if r in frozen_names and (root / r).is_file() and (root / r).read_bytes() == frozen.read(r):
            frozen_ok += 1
            continue
        outside.append(r)
    importers = []
    for r in git("ls-files", "-co", "--exclude-standard"):
        if r.endswith(".py") and not r.startswith(PHASE2_SCOPE):
            try:
                text = (root / r).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if re.search(r"^\s*(from|import)\s+(uri_supervisor|uri_supervisor_bridge)\b", text, re.M):
                importers.append(r)
    return {"changed_vs_closure": sorted(changed), "new_untracked": len(new), "modified_vs_head_outside_closure": sorted(modified),
            "frozen_phase1_byte_identical": frozen_ok, "outside_phase2_scope": outside,
            "phase1_scope_importers_of_phase2": importers}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("evidence")
    ap.add_argument("--bridge-runs", type=int, default=10)
    ap.add_argument("--no-native", action="store_true")
    ap.add_argument("--only", default="")
    ap.add_argument("--make-phase1-collection-baseline", action="store_true",
                    help="write the Phase 1 collection baseline; refused unless the phase1-scope check passes and the "
                         "collection size equals the independent baseline total")
    ap.add_argument("--baseline-full-log", default=str(ROOT.parent / "evidence" / "phase2ops_r6" / "phase1_full.log"))
    a = ap.parse_args()
    ev = Path(a.evidence)
    ev.mkdir(parents=True, exist_ok=True)
    if a.make_phase1_collection_baseline:
        scope = phase1_scope_check(ROOT, ROOT.parent / "evidence" / "phase2close-candidate-20261008-f.zip")
        if scope["outside_phase2_scope"] or scope["phase1_scope_importers_of_phase2"]:
            raise SystemExit("REFUSED: Phase 1 inputs differ from the accepted closure candidate: " + json.dumps(scope))
        coll = phase1_collection(ev / "phase1_collection_baseline.log")
        if len(coll) != BASELINE_TOTAL or COLLECTION_BASELINE.exists():
            raise SystemExit(f"REFUSED: collection size {len(coll)} != {BASELINE_TOTAL} or baseline file exists")
        COLLECTION_BASELINE.write_text("\n".join(coll) + "\n", encoding="utf-8")
        print(json.dumps({"written": str(COLLECTION_BASELINE), "tests": len(coll), "scope": {k: scope[k] for k in
                          ("frozen_phase1_byte_identical", "outside_phase2_scope", "phase1_scope_importers_of_phase2")}}))
        return 0
    only = set(filter(None, a.only.split(",")))
    want = lambda g: not only or g in only
    summary = {"started": time.strftime("%Y-%m-%dT%H:%M:%S"), "gates": {}}
    ok = True

    def record(name, result, passed):
        nonlocal ok
        summary["gates"][name] = {**result, "PASS": bool(passed)}
        ok = ok and bool(passed)
        print(name, json.dumps(summary["gates"][name])[:400], flush=True)
        (ev / "chain_summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")

    reg = [PY, "-I", "scripts/phase2d_regression.py"]
    if want("phase2"):
        code = run(reg + ["phase2"], ev / "phase2_all.log")
        c = pytest_counts(ev / "phase2_all.log")
        record("phase2", {"exit": code, **c}, code == 0 and c["failed"] == 0 and c["errors"] == 0 and c["passed"] > 0)
    if want("authority"):
        code = run(reg + ["authority"], ev / "phase1_authority.log")
        c = pytest_counts(ev / "phase1_authority.log")
        record("authority", {"exit": code, **c}, code == 0 and c["passed"] == 134 and c["failed"] == 0)
    if want("phase1-full"):
        env = {**os.environ, "OLLAMA_BASE_URL": "http://127.0.0.1:9"}
        log = ev / "phase1_full.log"
        code = run(reg + ["phase1-full", "--", "-rfEsp"], log, timeout=14400, env=env)
        c = pytest_counts(log)
        collected = phase1_collection(ev / "phase1_collection.log")
        bcoll = [l for l in COLLECTION_BASELINE.read_text(encoding="utf-8").splitlines() if l.strip()] if COLLECTION_BASELINE.is_file() else []
        good, details = phase1_equivalence(log, a.baseline_full_log, c, collected, bcoll)
        details["collection_baseline_file"] = str(COLLECTION_BASELINE)
        record("phase1-full", {"exit": code, **c, **details, "baseline_log": a.baseline_full_log,
                               "ollama_base_url": env["OLLAMA_BASE_URL"]}, good)
    if want("phase1-scope"):
        closure = ROOT.parent / "evidence" / "phase2close-candidate-20261008-f.zip"
        res = phase1_scope_check(ROOT, closure)
        record("phase1-scope", res, not res["outside_phase2_scope"] and not res["phase1_scope_importers_of_phase2"])
    if want("residue"):
        removed = []
        for name in RESIDUE:
            p = ROOT / name
            if p.is_file() and p.stat().st_size == 0:
                p.unlink()
                removed.append(name)
        record("residue", {"removed": removed}, all(not (ROOT / n).exists() for n in RESIDUE))
    if want("flutter"):
        flutter = Path.home() / "flutter/bin/flutter.bat"
        code = run([str(flutter), "test"], ev / "flutter_all.log", cwd=ROOT / "uri_ui")
        text = (ev / "flutter_all.log").read_text(encoding="utf-8", errors="replace")
        m = re.findall(r"\+(\d+)(?: ~(\d+))?(?: -(\d+))?: (All tests passed!|Some tests failed\.)", text)
        last = m[-1] if m else ("0", "0", "0", "")
        res = {"exit": code, "passed": int(last[0]), "skipped": int(last[1] or 0), "failed": int(last[2] or 0), "verdict": last[3]}
        record("flutter", res, code == 0 and res["verdict"] == "All tests passed!")
    if want("bridge"):
        results, refusals = [], []
        for i in range(1, a.bridge_runs + 1):
            code = run([PY, "-I", "scripts/phase2ops_validate_ui_bridge.py", "--log", str(ev / f"ui_bridge_live_{i}.json")],
                       ev / f"ui_bridge_stdout_{i}.txt", timeout=1800)
            data = {}
            try:
                data = json.loads((ev / f"ui_bridge_live_{i}.json").read_text(encoding="utf-8"))
                slog = Path(data["base"]) / "server" / "state" / "logs" / "phase2-server.log"
                cand = [slog] + list(Path(data["base"]).rglob("phase2-server.log"))
                for logp in cand:
                    if logp.is_file():
                        refusals += [f"run{i} " + l for l in logp.read_text(encoding="utf-8", errors="replace").splitlines()
                                     if l.startswith("CLIENT_REFUSAL")]
                        break
            except Exception as exc:  # noqa: BLE001
                data = {"error": type(exc).__name__}
            results.append({"run": i, "exit": code, "flutter_exit": data.get("exit")})
        (ev / "refusals.txt").write_text("\n".join(refusals) + ("\n" if refusals else ""), encoding="utf-8")
        passed = sum(1 for r in results if r["exit"] == 0 and r["flutter_exit"] == 0)
        record("bridge", {"runs": len(results), "passed": passed, "refusal_lines": len(refusals), "results": results},
               passed == len(results))
    if want("native") and not a.no_native:
        nat = ev / "native"
        nat.mkdir(exist_ok=True)
        code = run([PY, "-I", "scripts/phase2ops_native_execution.py", "--provider", "codex_cli", "--model", "gpt-6-sol",
                    "--evidence", str(nat)], ev / "native_codex_stdout.txt", timeout=3600)
        # The native script prints a one-line summary (`{"tag": ..., "runs": [{name, state, reason, code,
        # pid_after_cancel}]}`) before `REPORT <path>`; the report JSON keeps the raw per-run material instead.
        runs = {}
        try:
            lines = (ev / "native_codex_stdout.txt").read_text(encoding="utf-8", errors="replace").splitlines()
            summ = json.loads([l for l in lines if l.startswith('{"tag"')][-1])
            runs = {r.get("name"): {k: r.get(k) for k in ("state", "reason", "code", "pid_after_cancel")} for r in summ.get("runs") or []}
            runs["_qualification"] = summ.get("qualification")
            runs["_report"] = [l[7:] for l in lines if l.startswith("REPORT ")][-1:]
        except Exception as exc:  # noqa: BLE001
            runs = {"error": type(exc).__name__}
        good = (runs.get("lifecycle", {}).get("state") == "completed" and runs.get("lifecycle", {}).get("code") == "SETTLED_VERIFIED"
                and runs.get("mid_run_cancel", {}).get("state") == "uncertain"
                and runs.get("mid_run_cancel", {}).get("reason") == "CANCELLED_AFTER_DISPATCH"
                and runs.get("mid_run_cancel", {}).get("pid_after_cancel") == "DEAD")
        record("native", {"exit": code, "runs": runs}, code == 0 and good)
    if want("native-worker"):
        nw = ev / "native_worker"
        code = run([PY, "-I", "scripts/phase2oq_native_worker.py", "--evidence", str(nw)], ev / "native_worker_stdout.txt", timeout=3600)
        try:
            lines = (ev / "native_worker_stdout.txt").read_text(encoding="utf-8", errors="replace").splitlines()
            summ = json.loads([l for l in lines if l.startswith('{"tag"')][-1])
        except Exception as exc:  # noqa: BLE001
            summ = {"error": type(exc).__name__}
        lc = summ.get("L") or {}
        row = (summ.get("W_codex_row") or [{}])[0]
        good = (summ.get("probe") == "OK" and summ.get("logged_in") is False and row.get("status") == "QUALIFIED"
                and (summ.get("W_harness") or {}).get("usable") is False
                and summ.get("W_begin") == {"result": "REFUSED", "code": "HARNESS_NOT_USABLE"}
                and summ.get("W2") == [["INVALIDATED", "CODEX_WINDOWS_SANDBOX_NOT_CONFIGURED"]]
                and summ.get("W3") == [["INVALIDATED", "LAUNCH_CHAIN_RESOLUTION_CHANGED"]]
                and (lc.get("lifecycle") or {}).get("state") == "completed"
                and (lc.get("lifecycle") or {}).get("code") == "SETTLED_VERIFIED"
                and (lc.get("mid_run_cancel") or {}).get("state") == "uncertain"
                and (lc.get("mid_run_cancel") or {}).get("reason") == "CANCELLED_AFTER_DISPATCH"
                and (lc.get("mid_run_cancel") or {}).get("pid_after") == "DEAD"
                and (lc.get("mid_run_cancel") or {}).get("survivors") == 0)
        record("native-worker", {"exit": code, "summary": summ}, code == 0 and good)
    summary["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    summary["ALL_PASS"] = ok
    (ev / "chain_summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print("ALL_PASS" if ok else "CHAIN_FAILED", flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
