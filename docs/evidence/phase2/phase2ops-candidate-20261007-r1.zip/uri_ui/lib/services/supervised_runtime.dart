import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'paired_runtime.dart';

/// Phase 2 UI/operations: the supervised worker profile seen from the Flutter UI.
///
/// The frozen `WorkerPairedRuntime` (paired_runtime.dart, byte-identical to
/// the Phase 1 checkpoint) spawns the frozen worker named by the manifest. This
/// runtime spawns the Phase 2 COMPOSITION PROFILE (`scripts/run_uri_supervised_worker.py`)
/// instead, speaks the same framed stdio protocol, and adds the execution
/// lifecycle frames. It is an explicit, per-installation OPT-IN: the client
/// root must hold `control/ui-supervised-profile.json`; nothing in a manifest
/// or launcher is changed (no cutover). The UI never passes
/// `--allow-fixture-qualification`, never sees tickets or credentials, and
/// holds only execution ids: every state shown is re-read from the worker.
const supervisedProfileFile = 'control/ui-supervised-profile.json';
const supervisedProfileSchema = 'uri.phase2ops.ui_profile.v1';
const supervisedWorkerProfile = 'phase2d-supervised';
const supervisedWorkerEntrypoint = 'scripts/run_uri_supervised_worker.py';

const activeExecutionStates = {'queued', 'approving', 'starting', 'running'};
const terminalExecutionStates = {'completed', 'failed', 'cancelled', 'uncertain', 'quota_paused'};

/// What the approval is bound to. Shown verbatim; `proposalDigest` and
/// `approvalDigest` are echoed on `execution_begin` so the worker can refuse an
/// approval whose provider/model/arguments/turn differ from the card displayed.
class ExecutionProposal {
  const ExecutionProposal({
    required this.proposalDigest,
    required this.approvalDigest,
    required this.turnId,
    required this.sessionId,
    required this.kind,
    required this.provider,
    required this.model,
    required this.capabilityId,
    required this.argumentDigest,
    required this.effect,
    required this.reversible,
    required this.instruction,
    required this.expectedFile,
    required this.arguments,
    required this.qualification,
  });

  factory ExecutionProposal.fromJson(Map<String, dynamic> j) => ExecutionProposal(
        proposalDigest: j['proposal_digest'] as String,
        approvalDigest: j['approval_digest'] as String?,
        turnId: j['turn_id'] as String?,
        sessionId: j['session_id'] as String?,
        kind: j['kind'] as String?,
        provider: j['provider'] as String?,
        model: j['model'] as String?,
        capabilityId: j['capability_id'] as String?,
        argumentDigest: j['argument_digest'] as String?,
        effect: j['effect'] as String?,
        reversible: j['reversible'] as bool?,
        instruction: j['instruction'] as String?,
        expectedFile: j['expected_file'] as String?,
        arguments: (j['arguments'] as Map?)?.cast<String, dynamic>() ?? const {},
        qualification: (j['qualification'] as Map?)?.cast<String, dynamic>(),
      );

  final String proposalDigest;
  final String? approvalDigest;
  final String? turnId;
  final String? sessionId;
  final String? kind;
  final String? provider;
  final String? model;
  final String? capabilityId;
  final String? argumentDigest;
  final String? effect;
  final bool? reversible;
  final String? instruction;
  final String? expectedFile;
  final Map<String, dynamic> arguments;
  final Map<String, dynamic>? qualification;
}

/// A turn result from the supervised worker: the frozen envelope plus the
/// execution proposal when approval is required.
class SupervisedTurn extends TurnResult {
  const SupervisedTurn({
    required super.state,
    super.turnId,
    super.code,
    super.message,
    super.approval,
    super.clarification,
    super.confirmation,
    super.intent,
    this.proposal,
  });

  factory SupervisedTurn.fromJson(Map<String, dynamic> v) => SupervisedTurn(
        state: v['state'] as String,
        turnId: v['turn_id'] as String?,
        code: v['code'] as String?,
        message: v['message'] as String?,
        approval: (v['approval_request'] as Map?)?.cast<String, dynamic>(),
        clarification: (v['clarification'] as Map?)?.cast<String, dynamic>(),
        confirmation: (v['confirmation'] as Map?)?.cast<String, dynamic>(),
        intent: (v['intent'] as Map?)?.cast<String, dynamic>(),
        proposal: v['execution_proposal'] is Map
            ? ExecutionProposal.fromJson((v['execution_proposal'] as Map).cast<String, dynamic>())
            : null,
      );

  final ExecutionProposal? proposal;
}

class ExecutionHandle {
  const ExecutionHandle({required this.id, required this.turnId, required this.state, required this.proposalDigest});
  factory ExecutionHandle.fromJson(Map<String, dynamic> j) => ExecutionHandle(
      id: j['execution_id'] as String,
      turnId: j['turn_id'] as String,
      state: j['state'] as String,
      proposalDigest: j['proposal_digest'] as String);
  final String id;
  final String turnId;
  final String state;
  final String proposalDigest;
}

/// One execution as the worker reports it: its durable record plus the live
/// ledger, journal and server views. Never UI-derived.
class ExecutionStatus {
  const ExecutionStatus({
    required this.id,
    required this.turnId,
    required this.sessionId,
    required this.state,
    required this.reason,
    required this.code,
    required this.message,
    required this.requestText,
    required this.proposal,
    required this.taskId,
    required this.cancelRequested,
    required this.bridgeOutcome,
    required this.failureCategory,
    required this.evidence,
    required this.queuedAt,
    required this.approvingAt,
    required this.startingAt,
    required this.runningAt,
    required this.endedAt,
    required this.ledger,
    required this.journal,
    required this.serverTurn,
    required this.decision,
    required this.recordedState,
    required this.corroboration,
  });

  factory ExecutionStatus.fromJson(Map<String, dynamic> j) => ExecutionStatus(
        id: j['execution_id'] as String,
        turnId: j['turn_id'] as String?,
        sessionId: j['session_id'] as String?,
        state: j['state'] as String? ?? 'uncertain',
        reason: j['reason'] as String?,
        code: j['code'] as String?,
        message: j['message'] as String?,
        requestText: j['request_text'] as String?,
        proposal: j['proposal'] is Map
            ? ExecutionProposal.fromJson((j['proposal'] as Map).cast<String, dynamic>())
            : null,
        taskId: j['task_id'] as String?,
        cancelRequested: j['cancel_requested'] == true,
        bridgeOutcome: j['bridge_outcome'] as String?,
        failureCategory: j['failure_category'] as String?,
        evidence: (j['evidence'] as List?)?.map((e) => (e as Map).cast<String, dynamic>()).toList() ?? const [],
        queuedAt: (j['queued_at'] as num?)?.toDouble(),
        approvingAt: (j['approving_at'] as num?)?.toDouble(),
        startingAt: (j['starting_at'] as num?)?.toDouble(),
        runningAt: (j['running_at'] as num?)?.toDouble(),
        endedAt: (j['ended_at'] as num?)?.toDouble(),
        ledger: (j['ledger'] as Map?)?.cast<String, dynamic>(),
        journal: (j['journal'] as Map?)?.cast<String, dynamic>(),
        serverTurn: (j['server_turn'] as Map?)?.cast<String, dynamic>(),
        decision: j['decision'] as String?,
        recordedState: j['recorded_state'] as String?,
        corroboration: (j['corroboration'] as Map?)?.cast<String, dynamic>(),
      );

  final String id;
  final String? turnId;
  final String? sessionId;
  final String state;
  final String? reason;
  final String? code;
  final String? message;
  final String? requestText;
  final ExecutionProposal? proposal;
  final String? taskId;
  final bool cancelRequested;
  final String? bridgeOutcome;
  final String? failureCategory;
  final List<Map<String, dynamic>> evidence;
  final double? queuedAt;
  final double? approvingAt;
  final double? startingAt;
  final double? runningAt;
  final double? endedAt;
  final Map<String, dynamic>? ledger;
  final Map<String, dynamic>? journal;
  final Map<String, dynamic>? serverTurn;
  final String? decision;
  /// What the durable record itself says; [state] is what the worker could corroborate against ledger/journal/server.
  final String? recordedState;
  final Map<String, dynamic>? corroboration;

  bool get isTerminal => terminalExecutionStates.contains(state);
  bool get isActive => activeExecutionStates.contains(state);

  /// The ledger's task state, when the execution reached the supervisor.
  String? get ledgerTaskState => ((ledger?['task'] as Map?)?['state']) as String?;
  String? get journalState => journal?['state'] as String?;
  String? get serverTurnState => serverTurn?['state'] as String?;
}

class ExecutionSummary {
  const ExecutionSummary({
    required this.id,
    required this.turnId,
    required this.state,
    required this.reason,
    required this.code,
    required this.provider,
    required this.model,
    required this.queuedAt,
    required this.endedAt,
    required this.cancelRequested,
  });
  factory ExecutionSummary.fromJson(Map<String, dynamic> j) => ExecutionSummary(
        id: j['execution_id'] as String,
        turnId: j['turn_id'] as String?,
        state: j['state'] as String? ?? 'uncertain',
        reason: j['reason'] as String?,
        code: j['code'] as String?,
        provider: j['provider'] as String?,
        model: j['model'] as String?,
        queuedAt: (j['queued_at'] as num?)?.toDouble(),
        endedAt: (j['ended_at'] as num?)?.toDouble(),
        cancelRequested: j['cancel_requested'] == true,
      );
  final String id;
  final String? turnId;
  final String state;
  final String? reason;
  final String? code;
  final String? provider;
  final String? model;
  final double? queuedAt;
  final double? endedAt;
  final bool cancelRequested;
  bool get isActive => activeExecutionStates.contains(state);
}

class ExecutionListing {
  const ExecutionListing({required this.executions, required this.active, required this.startup});
  final List<ExecutionSummary> executions;
  final String? active;
  final Map<String, dynamic>? startup;
}

/// Boundary to the supervised worker. Everything here comes from the real
/// worker; the UI is never the authority for any of it.
abstract class SupervisedRuntime implements PairedRuntime {
  Future<Map<String, dynamic>> preflight();
  Future<ExecutionHandle> beginExecution(String turnId, String approvalDigest, String proposalDigest);
  Future<ExecutionStatus> executionStatus(String executionId);
  Future<Map<String, dynamic>> cancelExecution(String executionId);
  Future<ExecutionListing> listExecutions();
}

/// Real implementation over the Phase 2 worker profile.
class SupervisedWorkerRuntime implements SupervisedRuntime {
  SupervisedWorkerRuntime._(this._process);

  final Process _process;
  final _pending = <Completer<Map<String, dynamic>>>[];
  bool _listening = false;
  bool _closed = false;

  /// True only when a paired client installation is configured AND its client
  /// root carries the explicit supervised-profile opt-in file. Synchronous and
  /// read-only; never creates anything.
  static bool optInConfigured(String? manifestPath) {
    final manifest = _readManifest(manifestPath);
    if (manifest == null) return false;
    return _readOptIn(manifest) != null;
  }

  static Map<String, dynamic>? _readManifest(String? manifestPath) {
    if (manifestPath == null || manifestPath.isEmpty) return null;
    try {
      final file = File(manifestPath);
      if (!file.existsSync()) return null;
      final json = jsonDecode(file.readAsStringSync());
      return json is Map<String, dynamic> ? json : null;
    } catch (_) {
      return null;
    }
  }

  static Map<String, dynamic>? _readOptIn(Map<String, dynamic> manifest) {
    final root = manifest['client_root'];
    if (root is! String || root.isEmpty) return null;
    try {
      final file = File('$root${Platform.pathSeparator}${supervisedProfileFile.replaceAll('/', Platform.pathSeparator)}');
      if (!file.existsSync()) return null;
      final json = jsonDecode(file.readAsStringSync());
      if (json is! Map<String, dynamic>) return null;
      if (json['schema'] != supervisedProfileSchema || json['worker_profile'] != supervisedWorkerProfile) return null;
      return json;
    } catch (_) {
      return null;
    }
  }

  /// Returns null when the installation has not opted in. Spawns the Phase 2
  /// worker profile from the manifest's pinned `source_root` with the same
  /// interpreter and client root the frozen worker uses, then verifies through
  /// `preflight` that the worker really is the supervised profile.
  static Future<SupervisedWorkerRuntime?> fromManifest(String? manifestPath) async {
    final manifest = _readManifest(manifestPath);
    if (manifest == null || _readOptIn(manifest) == null) return null;
    final sourceRoot = manifest['source_root'] as String;
    final entrypoint = '$sourceRoot${Platform.pathSeparator}${supervisedWorkerEntrypoint.replaceAll('/', Platform.pathSeparator)}';
    return spawn(
      interpreter: manifest['interpreter'] as String,
      entrypoint: entrypoint,
      manifestPath: manifestPath!,
      workingDirectory: manifest['client_root'] as String,
    );
  }

  /// Spawns the worker and checks its profile. `extraArgs` exists for the live
  /// test harness only (fixture qualification); `fromManifest` never passes any.
  static Future<SupervisedWorkerRuntime> spawn({
    required String interpreter,
    required String entrypoint,
    required String manifestPath,
    required String workingDirectory,
    List<String> extraArgs = const [],
  }) async {
    final process = await Process.start(
      interpreter,
      ['-B', '-I', entrypoint, '--manifest', manifestPath, ...extraArgs],
      workingDirectory: workingDirectory,
    );
    final runtime = SupervisedWorkerRuntime._(process).._listen();
    try {
      final pre = await runtime.preflight();
      if (pre['worker_profile'] != supervisedWorkerProfile || pre['production_cutover'] != false) {
        throw PairedRuntimeException('WORKER_PROFILE_MISMATCH');
      }
      final lifecycle = pre['execution_lifecycle'];
      if (lifecycle is! List || !lifecycle.contains('execution_begin') || !lifecycle.contains('execution_cancel')) {
        throw PairedRuntimeException('EXECUTION_LIFECYCLE_UNAVAILABLE');
      }
    } catch (_) {
      await runtime.close();
      rethrow;
    }
    return runtime;
  }

  void _listen() {
    if (_listening) return;
    _listening = true;
    final bytes = <int>[];
    _process.stdout.listen((chunk) {
      bytes.addAll(chunk);
      while (bytes.length >= 4) {
        final size = ByteData.sublistView(Uint8List.fromList(bytes.sublist(0, 4))).getUint32(0, Endian.big);
        if (bytes.length < 4 + size) return;
        final body = utf8.decode(bytes.sublist(4, 4 + size));
        bytes.removeRange(0, 4 + size);
        if (_pending.isNotEmpty) {
          _pending.removeAt(0).complete(jsonDecode(body) as Map<String, dynamic>);
        }
      }
    }, onDone: () {
      for (final waiter in _pending) {
        waiter.completeError(PairedRuntimeException('WORKER_EXITED'));
      }
      _pending.clear();
    });
    _process.stderr.drain<void>();
  }

  Future<Map<String, dynamic>> _raw(Map<String, dynamic> command) {
    if (_closed) return Future.error(PairedRuntimeException('WORKER_CLOSED'));
    final completer = Completer<Map<String, dynamic>>();
    _pending.add(completer);
    final payload = utf8.encode(jsonEncode(command));
    final header = ByteData(4)..setUint32(0, payload.length, Endian.big);
    _process.stdin.add(header.buffer.asUint8List());
    _process.stdin.add(payload);
    return completer.future.timeout(const Duration(minutes: 5), onTimeout: () {
      throw PairedRuntimeException('WORKER_TIMEOUT');
    });
  }

  Future<Map<String, dynamic>> _call(Map<String, dynamic> command) async {
    final reply = await _raw(command);
    if (reply['result'] != 'OK') {
      throw PairedRuntimeException((reply['code'] as String?) ?? 'CLIENT_COMMAND_REFUSED');
    }
    return reply['value'] as Map<String, dynamic>;
  }

  @override
  Future<Map<String, dynamic>> preflight() => _call({'command': 'preflight'});

  @override
  Future<List<HarnessStatus>> discoverHarnesses() async {
    final value = await _call({'command': 'harness_discover'});
    return (value['harnesses'] as List).map((h) => HarnessStatus.fromJson(h as Map<String, dynamic>)).toList();
  }

  @override
  Future<TurnResult> startTurn(String sessionId, String text, ReasoningChoice choice) async =>
      SupervisedTurn.fromJson(await _call({
        'command': 'turn_start',
        'session_id': sessionId,
        'text': text,
        'reasoning': choice.toJson(),
      }));

  /// Frozen blocking decision (no lifecycle, no mid-run cancel). The screen
  /// uses [beginExecution]; this stays for protocol parity with the frozen UI.
  @override
  Future<TurnResult> decide(String turnId, bool approve) async =>
      SupervisedTurn.fromJson(await _call({'command': 'turn_decide', 'turn_id': turnId, 'approve': approve}));

  static const _decisionText = {'confirm': 'Confirm', 'abandon': 'Cancel that request', 'select': 'Selected option'};

  @override
  Future<TurnResult> intentDecision(String sessionId, ReasoningChoice choice, Map<String, dynamic> decision) async =>
      SupervisedTurn.fromJson(await _call({
        'command': 'turn_intent',
        'session_id': sessionId,
        'text': _decisionText[decision['decision']] ?? 'Decision',
        'reasoning': choice.toJson(),
        'intent_decision': decision,
      }));

  @override
  Future<ExecutionHandle> beginExecution(String turnId, String approvalDigest, String proposalDigest) async =>
      ExecutionHandle.fromJson(await _call({
        'command': 'execution_begin',
        'turn_id': turnId,
        'approval_digest': approvalDigest,
        'proposal_digest': proposalDigest,
      }));

  @override
  Future<ExecutionStatus> executionStatus(String executionId) async =>
      ExecutionStatus.fromJson(await _call({'command': 'execution_status', 'execution_id': executionId}));

  @override
  Future<Map<String, dynamic>> cancelExecution(String executionId) =>
      _call({'command': 'execution_cancel', 'execution_id': executionId});

  @override
  Future<ExecutionListing> listExecutions() async {
    final v = await _call({'command': 'execution_list'});
    return ExecutionListing(
      executions: (v['executions'] as List).map((e) => ExecutionSummary.fromJson(e as Map<String, dynamic>)).toList(),
      active: v['active'] as String?,
      startup: (v['startup'] as Map?)?.cast<String, dynamic>(),
    );
  }

  @override
  Future<void> close() async {
    if (_closed) return;
    try {
      // The worker withdraws any execution still in flight (job kill) before
      // it answers CLOSED, so a closing UI never leaves a harness running.
      await _raw({'command': 'close'}).catchError((_) => <String, dynamic>{});
    } finally {
      _closed = true;
      await _process.stdin.close();
    }
  }
}
