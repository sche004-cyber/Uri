"""Reconnect and restart: a new worker-side service on the same client (what a reopened UI gets) sees every earlier
execution from the durable register, re-reads the ledger/journal/server for its truth, marks whatever was in flight
`uncertain` (`WORKER_RESTARTED`), never relaunches, and cannot be talked into a second execution of the same work."""
import pytest

from phase2b.conftest import CLAUDE, uid
from phase2ops.conftest import TEXT, begin, cancel, listing, status, wait_running, wait_terminal
from uri_core.client_runtime.turn_runner import TurnError


def test_completed_execution_survives_a_worker_restart(stack, monkeypatch):
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    turn = stack.start(TEXT)
    eid = begin(stack, turn)["execution_id"]
    before = wait_terminal(stack, eid)
    fresh = stack.new_service()                                    # the UI reopened: a new worker on the same client
    rows = listing(stack, fresh)
    assert rows["active"] is None and rows["startup"]["executions"] == [] and [r["execution_id"] for r in rows["executions"]] == [eid]
    after = status(stack, eid, fresh)
    assert after["state"] == before["state"] == "completed" and after["task_id"] == before["task_id"]
    assert after["ledger"]["task"]["state"] == "COMPLETE" and after["server_turn"]["state"] == "reply"
    with pytest.raises(TurnError, match="EXECUTION_TERMINAL"):
        cancel(stack, eid, fresh)
    with pytest.raises(TurnError, match="TURN_NOT_PENDING"):           # the old approval is dead in the new worker
        begin(stack, turn, service=fresh)
    assert stack.tasks() == 1 and len(stack.result_files()) == 1


def test_in_flight_execution_is_uncertain_after_restart_and_is_never_relaunched(stack, monkeypatch):
    monkeypatch.setenv("URI_FAKE_SCENARIO", "hang")
    stack.bridge.timeout_s = stack.bridge.inactivity_s = 60
    turn = stack.start(TEXT)
    eid = begin(stack, turn)["execution_id"]
    running = wait_running(stack, eid)
    fresh = stack.new_service()                                    # restart while the attempt runs (in-process model)
    try:
        rows = listing(stack, fresh)
        assert rows["startup"]["executions"] == [{"execution_id": eid, "was": "running", "state": "uncertain", "reason": "WORKER_RESTARTED"}]
        st = status(stack, eid, fresh)
        assert st["state"] == "uncertain" and st["reason"] == "WORKER_RESTARTED" and st["previous_state"] == "running"
        assert st["restart_ledger"]["task_id"] == running["task_id"]
        with pytest.raises(TurnError, match="EXECUTION_TERMINAL"):
            cancel(stack, eid, fresh)
        with pytest.raises(TurnError, match="TURN_NOT_PENDING"):
            begin(stack, turn, service=fresh)
        with pytest.raises(TurnError, match="TURN_CAPACITY"):           # frozen rule: the session is held by that turn
            fresh.handle("turn_start", {"command": "turn_start", "session_id": turn["execution_proposal"]["session_id"],
                                        "text": TEXT, "reasoning": CLAUDE})
        assert stack.tasks() == 1 and stack.L.q1("SELECT COUNT(*) FROM attempt")[0] == 1
    finally:
        stack.bridge.cancel(running["task_id"])                      # the old (in-process) thread is withdrawn
        stack.service.executions._thread.join(40)


def test_server_unreachable_at_settle_is_uncertain_not_completed(stack, monkeypatch):
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    original = stack.runner.call

    def failing(method, path, body):
        if path.endswith("/settle"):
            return 503, {"detail": "SERVER_RESTARTING"}
        return original(method, path, body)
    monkeypatch.setattr(stack.runner, "call", failing)
    turn = stack.start(TEXT)
    eid = begin(stack, turn)["execution_id"]
    final = wait_terminal(stack, eid)
    assert final["state"] == "uncertain" and final["reason"].startswith("EXCEPTION:SERVER_REFUSED")
    assert final["bridge_outcome"] == "verified"                      # the work happened; URI will not call it done
    assert final["ledger"]["task"]["state"] == "COMPLETE" and final["journal"]["state"] == "verified"
    assert final["server_turn"]["state"] == "executing"                # the server never received the receipt
    rows = listing(stack, stack.new_service())["executions"]
    assert rows[0]["state"] == "uncertain"


def test_stale_ui_state_cannot_override_the_record(stack, monkeypatch):
    """A UI that still believes an execution runs asks again: it gets the terminal state, and nothing it sends
    (cancel, begin, decide) can move a terminal execution or re-run its work."""
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    turn = stack.start(TEXT)
    eid = begin(stack, turn)["execution_id"]
    wait_terminal(stack, eid)
    for _ in range(3):
        assert status(stack, eid)["state"] == "completed"
    with pytest.raises(TurnError, match="EXECUTION_TERMINAL"):
        cancel(stack, eid)
    with pytest.raises(TurnError, match="TURN_NOT_PENDING"):
        begin(stack, turn)
    with pytest.raises(TurnError, match="TURN_NOT_PENDING"):
        stack.decide(turn, True)
    assert stack.tasks() == 1 and stack.L.q1("SELECT COUNT(*) FROM attempt")[0] == 1


def test_unreadable_record_reports_uncertain_never_a_crash(stack, monkeypatch):
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    turn = stack.start(TEXT)
    eid = begin(stack, turn)["execution_id"]
    wait_terminal(stack, eid)
    p = stack.client_root / "control/supervisor/executions" / (eid + ".json")
    p.write_text("{not json", encoding="utf-8")
    st = status(stack, eid)
    assert st["state"] == "uncertain" and st["reason"] == "RECORD_UNREADABLE"
    p.write_text('{"schema": "other"}', encoding="utf-8")
    assert status(stack, eid)["reason"] == "RECORD_SCHEMA"
