"""Phase 2 closure: the power-loss harness's own logic (not a durability qualification; see the harness docstring)."""
import importlib.util
import sqlite3
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("pl", ROOT / "scripts" / "phase2close_powerloss_harness.py")
pl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pl)


def test_compare_flags_missing_and_regressed_steps_only():
    acked = {"t1": "ended", "t2": "intents", "t3": "submitted", "t4": "admitted"}
    present = {"t1": "ended", "t2": "admitted", "t4": "ended"}
    lost = pl.compare(acked, present)
    assert lost == [{"task_id": "t2", "acked": "intents", "present": "admitted"},
                    {"task_id": "t3", "acked": "submitted", "present": None}]
    assert pl.compare({}, present) == [] and pl.compare(acked, {**present, "t2": "ended", "t3": "submitted"}) == []


def _ledger_with_one_admitted_task(tmp_path):
    from dataclasses import replace
    from uri_supervisor.executors import GENERIC_NDJSON
    from uri_supervisor.supervisor import Supervisor
    db = tmp_path / "ledger.db"
    sup = Supervisor(str(db))
    sup.registry.create_pool("slot", 1)
    sup.registry.register_executor(replace(GENERIC_NDJSON, executor_id="plfake"), capabilities=("run",), claims={"slot": 1},
                                   quota_pools=(), preemptible=False, version="pl-1")
    sup.submit_task("pl-b1-000001", "t", {}, authorization={"scope": {}}, effects=[{"op_class": "read", "operation": "noop"}],
                    postconditions=[{"kind": "terminal_success"}], requirements={"capabilities": ["run"]})
    adm = sup.admit_next(only_task_id="pl-b1-000001")
    return sup, db, adm


def test_facts_report_the_highest_durable_step(tmp_path):
    sup, db, adm = _ledger_with_one_admitted_task(tmp_path)
    try:
        assert pl.ledger_facts(db, "pl-b1-")["steps"] == {"pl-b1-000001": "admitted"}
        sup.declare_intents(adm)
        facts = pl.ledger_facts(db, "pl-b1-")
        assert facts["steps"] == {"pl-b1-000001": "intents"} and facts["integrity"] == "ok" and facts["orphan_attempts"] == []
        assert pl.ledger_facts(db, "pl-b2-")["steps"] == {}
    finally:
        sup.close()


def test_the_ledger_itself_refuses_spawning_without_a_durable_intent(tmp_path):
    """Invariant (c) is enforced by the ledger's own trigger; the harness check is a second, read-only witness."""
    sup, db, adm = _ledger_with_one_admitted_task(tmp_path)
    sup.close()
    raw = sqlite3.connect(db)
    try:
        with pytest.raises(sqlite3.DatabaseError, match="NO_DURABLE_EFFECT_INTENT"):
            raw.execute("UPDATE attempt SET status='SPAWNING' WHERE attempt_id=?", (adm.attempt_id,))
    finally:
        raw.close()


def test_facts_flag_an_orphan_attempt_in_a_damaged_ledger(tmp_path):
    """If a power cut ever left an attempt SPAWNING/RUNNING without its admission or intents (the trigger above makes
    that impossible in a consistent file), the read-only check must say so and fail the invariants."""
    db = tmp_path / "damaged.db"
    raw = sqlite3.connect(db)
    raw.executescript("""
        CREATE TABLE task(task_id TEXT, state TEXT);
        CREATE TABLE admission(task_id TEXT, attempt_id INTEGER);
        CREATE TABLE effect_intent(task_id TEXT, attempt_id INTEGER);
        CREATE TABLE attempt(attempt_id INTEGER, task_id TEXT, status TEXT);
        INSERT INTO task VALUES ('pl-b1-000001', 'RUNNING');
        INSERT INTO admission VALUES ('pl-b1-000001', 1);
        INSERT INTO attempt VALUES (1, 'pl-b1-000001', 'SPAWNING');
    """)
    raw.commit()
    raw.close()
    out = pl.verify(str(db), "pl-b1-", recover=False)
    assert out["orphan_attempts"] == [{"attempt_id": 1, "task_id": "pl-b1-000001", "status": "SPAWNING", "admission": True, "intents": False}]
    assert out["in_flight_before_recovery"] == ["pl-b1-000001"] and out["invariants_ok"] is False


def test_verify_on_an_absent_ledger_says_so(tmp_path):
    assert pl.verify(str(tmp_path / "none.db")) == {"ledger": "ABSENT"}


def test_simulated_campaign_plumbing_end_to_end(tmp_path):
    """Two process-kill iterations through the real guest workload and the real host logic. SIMULATED: it proves the
    acks, the boot report, the comparison and the recovery checks work; it says nothing about power loss."""
    import subprocess
    out = tmp_path / "sim"
    r = subprocess.run([sys.executable, "-I", str(ROOT / "scripts" / "phase2close_powerloss_harness.py"), "simulate",
                        "--iterations", "2", "--out", str(out), "--min-s", "1.5", "--max-s", "2.5"],
                       cwd=str(ROOT), capture_output=True, text=True, timeout=600, stdin=subprocess.DEVNULL)
    assert r.returncode == 0, (r.stdout[-2000:], r.stderr[-2000:])
    import json
    summary = json.loads((out / "summary.json").read_text())
    rows = json.loads((out / "iterations.json").read_text())
    assert summary["verdict"] == "SIMULATED_ONLY_NOT_A_QUALIFICATION" and summary["passed"] == 2
    assert all(row["integrity"] == "ok" and row["lost"] == [] and row["acked_tasks"] >= 1 for row in rows)


# ---- closure review round 1, D2: no harness output can be mistaken for a physical qualification ----

def _summary(label="VM_SERIES", sync=("FULL",), verdict="SERIES_ALL_PASS", run=200, lost=0, method=True):
    return {"label": label, "synchronous": list(sync), "verdict": verdict, "iterations_run": run,
            "lost_acknowledged_steps": lost, "power_method": {"power_off": "Stop-VM"} if method else None}


def test_assess_requires_a_full_series_and_a_loss_detecting_control_and_never_qualifies():
    full, control = _summary(), _summary(sync=("NORMAL",), verdict="SERIES_FAIL", lost=3)
    ok = pl.assess(full, control)
    assert ok["verdict"] == "EVIDENCE_SUFFICIENT_PENDING_OWNER_ATTESTATION" and ok["qualified"] is False and ok["reasons"] == []
    bad_cases = [
        (_summary(run=199), control, "iterations"),
        (_summary(verdict="SERIES_FAIL"), control, "did not pass"),
        (full, _summary(sync=("NORMAL",), lost=0), "cannot detect loss"),
        (_summary(label="SIMULATED"), control, "not a VM series"),
        (full, _summary(label="SIMULATED", sync=("NORMAL",), lost=5), "not a VM series"),
        (_summary(sync=("NORMAL",)), control, "synchronous"),
        (full, _summary(sync=("FULL",), lost=2), "synchronous"),
        (_summary(method=False), control, "power method"),
    ]
    for f, c, why in bad_cases:
        res = pl.assess(f, c)
        assert res["verdict"] == "INSUFFICIENT" and res["qualified"] is False and any(why in r for r in res["reasons"]), (why, res)


def test_a_failed_power_command_stops_the_series_and_fails_it(tmp_path):
    """REAL local guest; the 'power off' reports failure: the series stops with POWER_OFF_COMMAND_FAILED."""
    out = tmp_path / "pf"
    out.mkdir()
    off, on = pl.local_power(out, out / "guest" / "ledger.db", "FULL")

    def failing_off():
        off()                    # really stop the guest so nothing is left running
        return False
    s = pl.campaign(out, 3, failing_off, on, 1.0, 1.5, 120, 0, "VM_SERIES", power_method={"power_off": "test"})
    rows = __import__("json").loads((out / "iterations.json").read_text())
    assert rows[-1]["verdict"] == "POWER_OFF_COMMAND_FAILED" and s["verdict"] == "SERIES_FAIL" and s["iterations_run"] == 1


def test_iteration_verdict_rules():
    ok = {"invariants_ok": True}
    assert pl.iteration_verdict({}, ok, []) == "NO_ACKED_WORK"
    assert pl.iteration_verdict({"t": "ended"}, ok, []) == "PASS"
    assert pl.iteration_verdict({"t": "ended"}, ok, [{"task_id": "t"}]) == "FAIL"
    assert pl.iteration_verdict({"t": "ended"}, {"invariants_ok": False}, []) == "FAIL"
    assert pl.iteration_verdict({"t": "ended"}, {}, []) == "FAIL"


def test_series_verdicts_never_say_qualified(tmp_path):
    src = (ROOT / "scripts" / "phase2close_powerloss_harness.py").read_text(encoding="utf-8")
    assert "ALL_ITERATIONS_PASS" not in src and "PHYSICAL_VM" not in src and '"qualified": False' in src
