"""Persisted qualification (Phase 2D): records are evidence, re-validated on every load; anything that drifts
(binary, version, record bytes, level, provider) leaves the provider NATIVE_UNQUALIFIED and unusable."""
import json
import shutil
import sys
from pathlib import Path

import pytest

from phase2b.conftest import CLAUDE, FAKE
from phase2d.conftest import fixture_record
from uri_supervisor_bridge.bridge import NOT_STARTED, SupervisorBridge
from uri_supervisor_bridge.qualification import (QualificationError, build_record, compose_client, load_records,
                                                 native_auth_probe, qualification_dir, record_digest, validate_shape, write_record)


def row(comp, provider):
    return next(r for r in comp.report if r["provider"] == provider)


def discover(comp, provider):
    return next(r for r in comp.registry.discover() if r["harness_id"] == provider)


def test_fixture_record_round_trip_qualifies_only_when_fixtures_are_allowed(tmp_path):
    client = tmp_path / "client"
    path, rec = fixture_record(client, "claude_code", (None, "m-1"))
    assert path == qualification_dir(client) / "claude_code.json" and validate_shape(json.loads(path.read_text()))
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, "claude_code")["status"] == "QUALIFIED" and comp.qualified() == ["claude_code"]
    d = discover(comp, "claude_code")
    assert d["usable"] is True and d["qualification"] == "FIXTURE_ONLY" and d["auth_state"] == "AUTHENTICATED"
    b = comp.executors["claude_code"]
    assert b.executable_sha256 == rec["executable_sha256"] and b.qualified_models == (None, "m-1") and b.version == "0.0.1"
    strict = compose_client(client, allow_fixture=False)
    assert row(strict, "claude_code")["reason"] == "LEVEL_NOT_ALLOWED" and strict.executors == {}
    assert discover(strict, "claude_code")["usable"] is False and discover(strict, "claude_code")["qualification"] == "NATIVE_UNQUALIFIED"


def test_nothing_persisted_means_nothing_qualified(tmp_path):
    comp = compose_client(tmp_path / "client")
    assert comp.report == [] and comp.executors == {} and all(not r["usable"] for r in comp.registry.discover())


def test_replaced_executable_invalidates(tmp_path):
    client = tmp_path / "client"
    exe = tmp_path / "python-copy.exe"
    shutil.copyfile(sys.executable, exe)
    # the copied interpreter cannot import its own stdlib from here: version probe fails, so build the record by hand
    ev = tmp_path / "ev.json"
    ev.write_text("{}")
    rec = build_record(provider="claude_code", level="FIXTURE_ONLY", spec_id="generic_ndjson", executable=exe, executable_args=[FAKE],
                       version="0.0.1", models=[None], evidence_path=ev, qualified_by="test")
    write_record(client, rec)
    exe.write_bytes(exe.read_bytes() + b"\0")
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, "claude_code")["reason"] == "EXECUTABLE_HASH_MISMATCH" and comp.executors == {}
    exe.unlink()
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, "claude_code")["reason"] == "EXECUTABLE_MISSING"


def test_version_drift_invalidates(tmp_path):
    client = tmp_path / "client"
    fixture_record(client, "claude_code", version="9.9.9")
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, "claude_code")["reason"] == "VERSION_MISMATCH" and comp.executors == {}


def test_hand_edited_record_is_refused(tmp_path):
    client = tmp_path / "client"
    path, rec = fixture_record(client, "claude_code", (None,))
    edited = {**rec, "models": [None, "sneaky-model"]}
    path.write_text(json.dumps(edited))
    assert load_records(client)[0]["error"] == "RECORD_DIGEST_MISMATCH"
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, "claude_code")["status"] == "INVALIDATED" and comp.executors == {}
    edited["record_sha256"] = record_digest(edited)        # re-signed by hand: accepted as a NEW record (same trust domain)
    edited["level"] = "NATIVE_QUALIFIED"                    # ...but not as a native qualification of a generic spec
    edited["record_sha256"] = record_digest(edited)
    path.write_text(json.dumps(edited))
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, "claude_code")["reason"] == "SPEC_PROVIDER_MISMATCH"


@pytest.mark.parametrize("bad", ["not json", "[]", "{}", '{"schema":"x"}'])
def test_corrupt_record_files_are_reported_not_trusted(tmp_path, bad):
    client = tmp_path / "client"
    d = qualification_dir(client)
    d.mkdir(parents=True)
    (d / "claude_code.json").write_text(bad)
    items = load_records(client)
    assert items[0]["record"] is None and items[0]["error"] in ("RECORD_UNREADABLE", "RECORD_SCHEMA")
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, "claude_code")["status"] == "INVALIDATED" and comp.executors == {}


def test_record_filename_must_name_its_provider(tmp_path):
    client = tmp_path / "client"
    path, rec = fixture_record(client, "claude_code")
    path.rename(path.with_name("codex_cli.json"))
    assert load_records(client)[0]["error"] == "RECORD_PROVIDER_FILENAME_MISMATCH"


@pytest.mark.parametrize("provider", ["antigravity", "unknownharness"])
def test_refused_or_unknown_providers_never_qualify(tmp_path, provider):
    client = tmp_path / "client"
    fixture_record(client, provider)
    comp = compose_client(client, allow_fixture=True)
    assert row(comp, provider)["reason"] == "PROVIDER_REFUSED_OR_UNKNOWN" and provider not in comp.executors
    if provider == "antigravity":
        assert discover(comp, provider)["qualification"] == "REFUSED"


def test_build_record_refuses_bad_inputs(tmp_path):
    ev = tmp_path / "ev.json"
    ev.write_text("{}")
    ok = dict(provider="claude_code", level="FIXTURE_ONLY", spec_id="generic_ndjson", executable=sys.executable, executable_args=[FAKE],
              version="0.0.1", models=[None], evidence_path=ev, qualified_by="t")
    for k, v, code in [("provider", "Bad Provider", "PROVIDER_ID_INVALID"), ("level", "SUPER", "LEVEL_INVALID"), ("spec_id", "nope", "SPEC_UNKNOWN"),
                       ("executable", tmp_path / "missing.exe", "EXECUTABLE_MISSING"), ("evidence_path", tmp_path / "no.json", "EVIDENCE_MISSING"),
                       ("models", [], "MODELS_REQUIRED"), ("models", ["bad model"], "MODEL_ID_INVALID")]:
        with pytest.raises(QualificationError, match=code):
            build_record(**{**ok, k: v})


def test_model_pin_refuses_an_unqualified_model_before_any_task(tmp_path, authority, monkeypatch):
    client = tmp_path / "client"
    fixture_record(client, "claude_code", ("m-1",))
    comp = compose_client(client, allow_fixture=True)
    b = SupervisorBridge(client, registry=comp.registry, executors=comp.executors, timeout_s=15, inactivity_s=4)
    try:
        monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
        signed, request, now = authority.issue()
        for model in (None, "m-2"):
            out = b.execute(authority.verify(signed, request, {**CLAUDE, "model": model}, now=now))
            assert out == ("failed", [], NOT_STARTED + "MODEL_NOT_QUALIFIED"), model
        assert b.L.q1("SELECT COUNT(*) FROM task")[0] == 0
        assert b.execute(authority.verify(signed, request, {**CLAUDE, "model": "m-1"}, now=now))[0] == "verified"
    finally:
        b.close()


def test_native_record_needs_live_authentication(tmp_path):
    """A NATIVE_QUALIFIED record for codex_cli pointing at the fake executable (version/hash valid): the registry row
    is NATIVE_QUALIFIED but usable only when the live auth probe says so. Nothing is persisted about auth."""
    client = tmp_path / "client"
    ev = tmp_path / "ev.json"
    ev.write_text("{}")
    rec = build_record(provider="codex_cli", level="NATIVE_QUALIFIED", spec_id="codex_cli", executable=sys.executable, executable_args=[FAKE],
                       version="0.0.1", models=["gpt-6-sol"], evidence_path=ev, qualified_by="t")
    write_record(client, rec)
    for verdict, state, usable in ((True, "AUTHENTICATED", True), (False, "NOT_AUTHENTICATED", False), (None, "AUTH_UNVERIFIED", False)):
        comp = compose_client(client, auth_probe=lambda hid, v=verdict: v)
        d = discover(comp, "codex_cli")
        assert (d["qualification"], d["auth_state"], d["usable"]) == ("NATIVE_QUALIFIED", state, usable)
        assert row(comp, "codex_cli")["status"] == "QUALIFIED"
    # default probe runs the CLI's own status command against THIS executable: the fake answers nonsense -> False
    comp = compose_client(client)
    assert discover(comp, "codex_cli")["usable"] is False
    assert native_auth_probe("codex_cli", sys.executable) is False and native_auth_probe("other", sys.executable) is None
    assert native_auth_probe("claude_code", sys.executable) is None       # not JSON -> unknown


def test_live_status_probe_on_installed_clis_never_raises():
    """REAL CLIs if installed: the probe only runs the status subcommand (never logs in)."""
    import shutil as sh
    for provider, exe in (("codex_cli", "codex"), ("claude_code", "claude")):
        path = sh.which(exe)
        if path is None:
            continue
        assert native_auth_probe(provider, path) in (True, False, None)


@pytest.mark.parametrize("stream,text,exit_code,expect", [
    ("2", "Logged in using ChatGPT", 0, True),      # D-D1: Codex 0.158.0 reports on STDERR with exit 0
    ("1", "Logged in using ChatGPT", 0, True),
    ("1", "Not logged in", 1, False),
    ("2", "Not logged in", 0, False),
    ("1", "", 1, False),
])
def test_codex_status_probe_reads_both_streams_and_exit_status(tmp_path, stream, text, exit_code, expect):
    """Regression for defect D-D1 (Phase 2D): the live status probe read stdout only, so a logged-in Codex (which
    prints on stderr) was reported NOT_AUTHENTICATED. A .cmd stand-in reproduces each stream/exit combination."""
    shim = tmp_path / "codex.cmd"
    echo = (f"echo {text} 1>&2" if stream == "2" else f"echo {text}") if text else ""
    body = "@echo off\r\n" + (echo + "\r\n" if echo else "") + f"exit /b {exit_code}\r\n"
    shim.write_bytes(body.encode("ascii"))
    assert native_auth_probe("codex_cli", str(shim)) is expect
