"""Phase 2D self-audit (author's own attack, NOT an independent audit). Each case names the control it probes.
Cases already pinned by earlier suites are referenced, not duplicated. SYNTHETIC executor; REAL server where used."""
import json
import re
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from phase2b.conftest import CLAUDE, CODEX, uid
from phase2d.conftest import ROOT, fixture_record
from uri_core.client_runtime.turn_runner import TurnError
from uri_supervisor.ledger import LedgerError
from uri_supervisor_bridge.bridge import NOT_STARTED, SupervisorBridge
from uri_supervisor_bridge.qualification import compose_client

TEXT = "use the harness to write a greeting into out.txt"


# -- modified intent / approval digest after confirmation (real server, protocol level) ----------------------------

def test_rogue_ui_editing_the_approval_envelope_cannot_change_what_runs(stack, monkeypatch):
    """A UI that holds the approval envelope and edits the arguments: the worker approves by digest, the server issues
    a ticket for ITS pending arguments, and the bridge re-verifies the arguments it will run against that ticket."""
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    turn = stack.start(TEXT)
    entry = stack.service.pending[turn["turn_id"]]
    entry[3]["approval_request"]["arguments"]["inputs"]["instruction"] = "write a greeting and delete everything"
    final = stack.decide(turn, True)
    assert final["code"] == "SETTLED_FAILED" and stack.tasks() == 0           # ARGUMENT_DIGEST_MISMATCH before any task


def test_rogue_ui_editing_the_approval_digest_is_refused_by_the_server(stack, monkeypatch):
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    turn = stack.start(TEXT)
    entry = stack.service.pending[turn["turn_id"]]
    entry[3]["approval_request"]["approval_digest"] = "f" * 64
    with pytest.raises(TurnError, match="APPROVAL_DIGEST_MISMATCH"):
        stack.decide(turn, True)
    assert stack.tasks() == 0


def test_provider_swap_inside_the_pending_record_is_refused_before_any_executor(stack, monkeypatch):
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    turn = stack.start(TEXT, reasoning=CLAUDE)
    text, session, reasoning, env = stack.service.pending[turn["turn_id"]]
    stack.service.pending[turn["turn_id"]] = (text, session, CODEX, env)   # UI/worker memory tampered after begin
    final = stack.decide(turn, True)
    assert final["code"] == "SETTLED_FAILED" and stack.tasks() == 0         # AUTHORITY_SELECTION_MISMATCH (D-C1)


# -- forged ticket at the protocol boundary ---------------------------------------------------------------------------

def test_forged_ticket_handed_to_the_worker_is_a_schema_violation(stack):
    with pytest.raises(TurnError, match="COMMAND_SCHEMA"):
        stack.service.handle("turn_decide", {"command": "turn_decide", "turn_id": uid(), "approve": True, "ticket": {"forged": 1}})
    with pytest.raises(TurnError, match="COMMAND_SCHEMA"):
        stack.service.handle("turn_execute", {"command": "turn_execute", "ticket": {"forged": 1}})


# -- stale qualification: binary swap between qualification and use ------------------------------------------------

def test_executable_replaced_after_qualification_is_refused_at_both_layers(tmp_path, authority, monkeypatch):
    """Mirrors the real case (npm `codex.CMD` shim): the qualified executable is a .cmd launcher. Replacing its bytes
    after qualification is refused by the bridge pin (if the bridge already composed) and by re-validation (next load)."""
    from phase2b.conftest import FAKE
    from uri_supervisor_bridge.qualification import build_record, write_record
    client = tmp_path / "client"
    shim = tmp_path / "fake-harness.cmd"
    shim.write_bytes(("@\"%s\" \"%s\" %%*" % (sys.executable, FAKE)).encode("ascii") + bytes([13, 10]))
    ev = tmp_path / "ev.json"
    ev.write_text("{}")
    rec = build_record(provider="claude_code", level="FIXTURE_ONLY", spec_id="generic_ndjson", executable=shim, executable_args=[],
                       version="0.0.1", models=[None], evidence_path=ev, qualified_by="t")
    write_record(client, rec)
    comp = compose_client(client, allow_fixture=True)
    assert comp.qualified() == ["claude_code"], comp.report
    b = SupervisorBridge(client, registry=comp.registry, executors=comp.executors, timeout_s=10, inactivity_s=3)
    try:
        shim.write_bytes(shim.read_bytes() + b"rem swapped" + bytes([13, 10]))   # swapped AFTER composition
        monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
        signed, request, now = authority.issue()
        out = b.execute(authority.verify(signed, request, CLAUDE, now=now))
        assert out == ("failed", [], NOT_STARTED + "EXECUTOR_BINARY_HASH_MISMATCH") and b.L.q1("SELECT COUNT(*) FROM task")[0] == 0
    finally:
        b.close()
    assert compose_client(client, allow_fixture=True).report[0]["reason"] == "EXECUTABLE_HASH_MISMATCH"


# -- corrupted persisted state ----------------------------------------------------------------------------------------

def test_corrupted_ledger_refuses_the_bridge_and_runs_nothing(tmp_path):
    from phase2b.conftest import fake_binding, fake_registry
    client = tmp_path / "client"
    db = client / "control" / "supervisor" / "ledger.db"
    db.parent.mkdir(parents=True)
    db.write_bytes(b"this is not a sqlite database" * 100)
    with pytest.raises((LedgerError, sqlite3.DatabaseError)):
        SupervisorBridge(client, registry=fake_registry("claude_code"), executors={"claude_code": fake_binding("claude_code")})


def test_corrupted_qualification_record_runs_nothing(tmp_path, authority, monkeypatch):
    client = tmp_path / "client"
    path, rec = fixture_record(client, "claude_code")
    path.write_bytes(path.read_bytes()[:-20])
    comp = compose_client(client, allow_fixture=True)
    assert comp.executors == {} and comp.report[0]["status"] == "INVALIDATED"
    b = SupervisorBridge(client, registry=comp.registry, executors=comp.executors)
    try:
        monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
        signed, request, now = authority.issue()
        out = b.execute(authority.verify(signed, request, CLAUDE, now=now))
        assert out[0] == "failed" and out[2].startswith(NOT_STARTED) and b.L.q1("SELECT COUNT(*) FROM task")[0] == 0
    finally:
        b.close()


# -- duplicate submit / duplicate resume ----------------------------------------------------------------------------

def test_duplicate_submit_of_a_verified_intent_is_blocked_by_the_server_ledger(stack, monkeypatch):
    """Replayed client state after a verified run: INTENT_ALREADY_EXECUTED (frozen guard), zero new tasks."""
    monkeypatch.setenv("URI_FAKE_SCENARIO", "honest")
    session = uid()
    before = stack.persistence.snapshot(session, []).model_dump()
    turn = stack.start(TEXT, session=session)
    confirmed_session = stack.service.pending[turn["turn_id"]][3].get("session_update")
    assert stack.decide(turn, True)["code"] == "SETTLED_VERIFIED"
    assert stack.tasks() == 1
    # replay: feed the server the pre-execution confirmed session (as a restored device would)
    from uri_core.client_contracts import ReadQuery
    if confirmed_session is not None:
        stack.runner._commit_consented(session, [("sessions", "get_session", [session], "save_session", {"session_id": session}, confirmed_session)])
        again = stack.runner.begin("Confirm", session, CLAUDE, None)
        assert again.get("code") in ("INTENT_ALREADY_EXECUTED", "INTENT_STATE_STALE", "CONVERSATION", "INTENT_CONFIRMED_NOT_EXECUTED") or again["state"] != "approval_required", again
    assert stack.tasks() == 1 and len(stack.result_files()) == 1


# -- the two frozen worker profiles never read native credential stores ---------------------------------------------

def test_phase2_profiles_contain_no_credential_or_login_paths():
    for rel in ("scripts/run_uri_supervised_worker.py", "scripts/run_uri_phase2_server.py", "uri_supervisor_bridge/qualification.py",
                "uri_supervisor_bridge/composition.py", "uri_supervisor_bridge/worker_service.py"):
        text = (ROOT / rel).read_text(encoding="utf-8")
        code = "\n".join(l for l in text.splitlines() if not l.strip().startswith("#") and not l.strip().startswith('"""'))
        for token in ("auth.json", ".credentials", "login\"]", "\"login\",", "'login',", "setup-token", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"):
            if token in ("\"login\",", "'login',") and "login\", \"status\"" in code:
                continue
            assert token not in code, (rel, token)
    # the only `login` the composition ever spells is the read-only status subcommand
    q = (ROOT / "uri_supervisor_bridge/qualification.py").read_text(encoding="utf-8")
    assert re.findall(r"\"login\",\s*\"status\"", q) and "codex login\"" not in q


# -- a second live worker on the same client is refused (reconnect cannot double-execute) ----------------------------

def test_two_live_phase2_workers_on_one_client_are_refused():
    """Static pin of the frozen single-instance mutex in the Phase 2 worker profile (the dynamic proof is the frozen
    C3 worker test suite; this guards against the profile dropping the gate)."""
    text = (ROOT / "scripts/run_uri_supervised_worker.py").read_text(encoding="utf-8")
    assert 'NamedMutex("Local\\\\URI_Client_" + m["client_id"], 0)' in text
    assert "install_source_pin(" in text and "FixtureGuard(" in text and "sys.addaudithook(guard)" in text
    assert "CLIENT_CWD_MISMATCH" in text and "CLIENT_KEY_MISMATCH" in text and "CLIENT_PROCESS_IMAGE" in text


def test_frozen_entrypoints_and_ui_untouched():
    """Cutover never happened: the frozen worker, server, launcher and UI still compose Phase 1 exactly."""
    worker = (ROOT / "scripts/run_uri_client_worker.py").read_text(encoding="utf-8")
    assert "TurnService(manifest, persistence, harness=harnesses)" in worker and "uri_supervisor" not in worker
    server = (ROOT / "scripts/run_uri_isolated_server.py").read_text(encoding="utf-8")
    assert "default_composition()" in server and "uri_supervisor" not in server
    ui = (ROOT / "uri_ui/lib/services/paired_runtime.dart").read_text(encoding="utf-8")
    assert "manifest['worker_entrypoint']" in ui and "supervised" not in ui


def test_phase2_test_scope_cannot_collect_preserved_runtime_state():
    ini = (ROOT / "scripts/phase2d_pytest.ini").read_text(encoding="utf-8")
    assert "norecursedirs" in ini and " work " in ini + " " and "evidence" in ini
    r = subprocess.run([sys.executable, "-I", "-m", "pytest", "-c", str(ROOT / "scripts/phase2d_pytest.ini"), "--rootdir", str(ROOT),
                        "--collect-only", "-q", "tests/phase2d/test_policy_composition.py"], capture_output=True, text=True, cwd=str(ROOT), timeout=300)
    assert r.returncode == 0 and "work/c1" not in r.stdout and "rollback_" not in r.stdout, r.stdout[-500:]


# -- crash after ledger COMPLETE, before the bridge settles (copy-out / receipt never happened) ------------------------

def test_crash_after_complete_before_settlement_never_relaunches_and_closes_authority(tmp_path):
    """The supervisor commits COMPLETE (`recovery_after_decision` crash point) and the bridge dies before `_settle`:
    no result was copied out, no receipt was built. Restart: the task stays COMPLETE, its still-open authorization is
    revoked, nothing launches, the same ticket is DUPLICATE_OPERATION (the frozen journal/server then hold the turn as
    execution_uncertain: a verified receipt can only come from a live bridge settlement)."""
    from phase2b.conftest import SyntheticAuthority, fake_binding, fake_registry
    from phase2b.test_bridge_restart import cfg_for, child, effects
    auth = SyntheticAuthority()
    cfg, signed, request, now = cfg_for(tmp_path, auth, scenario="honest")
    r = child(cfg, crash_at="recovery_after_decision")
    assert r.returncode == 137, r.stderr[-500:]
    assert effects(tmp_path) == 1
    client = tmp_path / "client"
    assert not list((client / "workspace" / "results").rglob("*")) if (client / "workspace" / "results").exists() else True
    b = SupervisorBridge(client, registry=fake_registry("claude_code"), executors={"claude_code": fake_binding("claude_code")},
                         timeout_s=20, inactivity_s=5)
    try:
        work = auth.verify(signed, request, CLAUDE, now=now)
        t = b.L.task(work.task_id)
        assert t["state"] == "COMPLETE"
        assert b.reconcile_restart() == [{"task_id": work.task_id, "was": "COMPLETE", "state": "COMPLETE", "authority": "revoked"}]
        open_auth = b.L.q1("SELECT COUNT(*) FROM authorization WHERE task_id=? AND superseded_at_us IS NULL AND (valid_until_us IS NULL OR valid_until_us>?)",
                           (work.task_id, b.L.now_us()))[0]
        assert open_auth == 0
        assert b.execute(work) == ("execution_uncertain", [], "DUPLICATE_OPERATION")
        assert b.L.q1("SELECT COUNT(*) FROM attempt WHERE task_id=?", (work.task_id,))[0] == 1 and effects(tmp_path) == 1
    finally:
        b.close()
