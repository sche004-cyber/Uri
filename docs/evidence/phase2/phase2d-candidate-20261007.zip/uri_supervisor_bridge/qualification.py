"""Phase 2D: persisted, evidence-backed executor qualification for the client-side composition.

A qualification record says: THIS provider, run as THIS executable file (path + SHA-256 + reported version) with
THESE models, was qualified at THIS level on the strength of THIS evidence file. It is data in the client's own
state root (`<client_root>/control/supervisor/qualification/<provider>.json`), written only by a trusted
qualification run and re-validated on every load:

  * the executable must still resolve to the recorded file and hash to the recorded SHA-256;
  * `--version` must still report the recorded version;
  * the record digest must match (a hand-edited record is refused);
  * `FIXTURE_ONLY` records are honoured only when the composition explicitly allows fixtures (tests);
  * the recorded models become the bridge's `qualified_models` pin, so another model never inherits the evidence.

Anything that fails re-validation leaves the provider exactly where the frozen Phase 1 registry leaves it by
default: `NATIVE_UNQUALIFIED`, not usable, nothing executes. Authentication is never persisted: it is probed
live (`codex login status`, `claude auth status`) with the harness environment allow-list, never by reading a
credential file and never by logging in.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import time
import uuid
from dataclasses import dataclass, replace
from pathlib import Path

from uri_core.client_runtime.harness import HarnessRegistry, harness_env, probe_version, resolve_command
from uri_supervisor.executors import BUILTIN_SPECS, GENERIC_NDJSON, ExecutorSpec

from .bridge import ExecutorBinding, _file_sha256, _same_file

SCHEMA = "uri.phase2d.qualification.v1"
LEVELS = ("NATIVE_QUALIFIED", "FIXTURE_ONLY")
_PROVIDER = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_MODEL = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
REQUIRED = ("schema", "provider", "level", "spec_id", "executable", "executable_args", "executable_sha256", "version",
            "models", "evidence_sha256", "evidence_path", "qualified_at", "qualified_by", "record_sha256")
# Live, read-only authentication status commands. Exit 0 = authenticated for Codex; Claude prints JSON.
AUTH_STATUS_ARGV = {"codex_cli": ("login", "status"), "claude_code": ("auth", "status")}
AUTH_VARS = {"claude_code": ("CLAUDE_CODE_OAUTH_TOKEN",), "codex_cli": ("CODEX_API_KEY", "CODEX_HOME")}


class QualificationError(ValueError):
    def __init__(self, code, detail=None):
        super().__init__(code if detail is None else f"{code}: {detail}")
        self.code, self.detail = code, detail


def qualification_dir(client_root) -> Path:
    return Path(client_root).resolve() / "control" / "supervisor" / "qualification"


def _canonical(record: dict) -> bytes:
    return json.dumps({k: v for k, v in record.items() if k != "record_sha256"}, sort_keys=True,
                      separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def record_digest(record: dict) -> str:
    return hashlib.sha256(_canonical(record)).hexdigest()


def build_record(*, provider, level, spec_id, executable, executable_args, version, models, evidence_path,
                 qualified_by, notes=None) -> dict:
    """Build a record from observed facts. The caller is the trusted qualification run; this function only
    hashes what it is given (executable file, evidence file) and refuses malformed input."""
    if not isinstance(provider, str) or not _PROVIDER.fullmatch(provider):
        raise QualificationError("PROVIDER_ID_INVALID")
    if level not in LEVELS:
        raise QualificationError("LEVEL_INVALID", str(level))
    if spec_id not in BUILTIN_SPECS:
        raise QualificationError("SPEC_UNKNOWN", str(spec_id))
    exe = Path(executable)
    if not exe.is_file():
        raise QualificationError("EXECUTABLE_MISSING")
    args = [str(a) for a in (executable_args or [])]
    ev = Path(evidence_path)
    if not ev.is_file():
        raise QualificationError("EVIDENCE_MISSING")
    if not isinstance(models, (list, tuple)) or not models:
        raise QualificationError("MODELS_REQUIRED")
    for m in models:
        if m is not None and (not isinstance(m, str) or not _MODEL.fullmatch(m)):
            raise QualificationError("MODEL_ID_INVALID", str(m))
    if version is not None and not isinstance(version, str):
        raise QualificationError("VERSION_INVALID")
    record = {"schema": SCHEMA, "provider": provider, "level": level, "spec_id": spec_id,
              "executable": str(exe.resolve()), "executable_args": args, "executable_sha256": _file_sha256(exe),
              "version": version, "models": list(models), "evidence_sha256": _file_sha256(ev), "evidence_path": str(ev.resolve()),
              "qualified_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "qualified_by": str(qualified_by), "notes": notes or ""}
    record["record_sha256"] = record_digest(record)
    return record


def write_record(client_root, record: dict) -> Path:
    """Atomic write of one provider's record (replaces an older record for the same provider)."""
    validate_shape(record)
    d = qualification_dir(client_root)
    d.mkdir(parents=True, exist_ok=True)
    path = d / (record["provider"] + ".json")
    tmp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    with open(tmp, "x", encoding="utf-8") as f:
        json.dump(record, f, indent=1, sort_keys=True)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    return path


def validate_shape(record) -> dict:
    if not isinstance(record, dict) or set(record) - set(REQUIRED) - {"notes"} or any(k not in record for k in REQUIRED):
        raise QualificationError("RECORD_SCHEMA")
    if record["schema"] != SCHEMA:
        raise QualificationError("RECORD_SCHEMA", "schema")
    if not isinstance(record["provider"], str) or not _PROVIDER.fullmatch(record["provider"]):
        raise QualificationError("RECORD_SCHEMA", "provider")
    if record["level"] not in LEVELS:
        raise QualificationError("RECORD_SCHEMA", "level")
    if record["spec_id"] not in BUILTIN_SPECS:
        raise QualificationError("RECORD_SCHEMA", "spec_id")
    if not isinstance(record["executable"], str) or not record["executable"]:
        raise QualificationError("RECORD_SCHEMA", "executable")
    if not isinstance(record["executable_args"], list) or any(not isinstance(a, str) for a in record["executable_args"]):
        raise QualificationError("RECORD_SCHEMA", "executable_args")
    for key in ("executable_sha256", "evidence_sha256", "record_sha256"):
        if not isinstance(record[key], str) or not _HEX64.fullmatch(record[key]):
            raise QualificationError("RECORD_SCHEMA", key)
    if record["version"] is not None and not isinstance(record["version"], str):
        raise QualificationError("RECORD_SCHEMA", "version")
    models = record["models"]
    if not isinstance(models, list) or not models or any(m is not None and (not isinstance(m, str) or not _MODEL.fullmatch(m)) for m in models):
        raise QualificationError("RECORD_SCHEMA", "models")
    if record_digest(record) != record["record_sha256"]:
        raise QualificationError("RECORD_DIGEST_MISMATCH")
    return record


def load_records(client_root) -> list:
    """Every record file, parsed or marked unreadable. Never raises for one bad file."""
    out = []
    d = qualification_dir(client_root)
    if not d.is_dir():
        return out
    for p in sorted(d.glob("*.json")):
        try:
            rec = json.loads(p.read_text(encoding="utf-8"))
            validate_shape(rec)
            if rec["provider"] != p.stem:
                raise QualificationError("RECORD_PROVIDER_FILENAME_MISMATCH")
            out.append({"path": str(p), "record": rec, "error": None})
        except (OSError, ValueError) as exc:
            code = exc.code if isinstance(exc, QualificationError) else "RECORD_UNREADABLE"
            out.append({"path": str(p), "record": None, "error": code})
    return out


def native_auth_probe(provider, executable, environ=None, timeout_s=30):
    """Live read-only authentication status. True / False / None (unknown). Never logs in, never reads a credential
    file: the CLI's own status command decides, under the same environment allow-list the executor gets."""
    argv = AUTH_STATUS_ARGV.get(provider)
    if argv is None:
        return None
    env = harness_env(AUTH_VARS.get(provider, ()), environ)
    try:
        p = subprocess.run([executable, *argv], capture_output=True, timeout=timeout_s, stdin=subprocess.DEVNULL, env=env)
    except (OSError, subprocess.TimeoutExpired):
        return None
    out = p.stdout.decode("utf-8", "replace")
    err = p.stderr.decode("utf-8", "replace")
    if provider == "claude_code":
        try:
            data = json.loads(out)
            return bool(data.get("loggedIn")) if isinstance(data, dict) else None
        except ValueError:
            return None
    # Codex 0.158.0 prints "Logged in using ChatGPT" on STDERR with exit 0 (Phase 2D defect D-D1: stdout alone read as
    # "not logged in"). "Not logged in" exits non-zero. Both streams are inspected; exit status decides first.
    text = (out + chr(10) + err).lower()
    if p.returncode != 0 or "not logged in" in text:
        return False
    return "logged in" in text


@dataclass(frozen=True)
class ClientComposition:
    registry: HarnessRegistry
    executors: dict
    report: list          # one row per record file: provider, status (QUALIFIED | INVALIDATED), reason, level, ...
    allow_fixture: bool

    def qualified(self):
        return sorted(r["provider"] for r in self.report if r["status"] == "QUALIFIED")


def _spec_for(record) -> ExecutorSpec:
    spec = BUILTIN_SPECS[record["spec_id"]]
    if record["level"] == "FIXTURE_ONLY":
        if record["spec_id"] != GENERIC_NDJSON.executor_id:
            raise QualificationError("FIXTURE_SPEC_REQUIRED")
        return replace(GENERIC_NDJSON, executor_id=record["provider"], stdin="instructions")
    if spec.executor_id != record["provider"]:
        raise QualificationError("SPEC_PROVIDER_MISMATCH")
    return spec


def revalidate(record, *, allow_fixture=False) -> tuple:
    """-> (spec, resolved executable, args) or raises QualificationError with the invalidation reason."""
    if record["level"] == "FIXTURE_ONLY" and not allow_fixture:
        raise QualificationError("LEVEL_NOT_ALLOWED", "FIXTURE_ONLY")
    spec = _spec_for(record)
    exe = record["executable"]
    cmd = resolve_command(exe)
    if not cmd or not Path(exe).is_file() or _same_file(cmd[0], exe) is not True:
        raise QualificationError("EXECUTABLE_MISSING")
    if _file_sha256(exe) != record["executable_sha256"]:
        raise QualificationError("EXECUTABLE_HASH_MISMATCH")
    for a in record["executable_args"]:
        if Path(a).is_absolute() and Path(a).suffix == ".py" and not Path(a).is_file():
            raise QualificationError("EXECUTABLE_ARGS_MISSING")
    probe = probe_version([exe, *record["executable_args"]])
    if not probe["installed"] or probe["version"] != record["version"] or record["version"] is None:
        raise QualificationError("VERSION_MISMATCH", f"{probe.get('version')} != {record['version']}")
    return spec, exe, list(record["executable_args"])


def compose_client(client_root, *, allow_fixture=False, auth_probe=None, environ=None, adapters_factory=None) -> ClientComposition:
    """Phase 1 `HarnessRegistry` (all adapters, nothing qualified) plus every persisted record that re-validates now.

    `auth_probe(harness_id) -> True|False|None` defaults to the live CLI status probe for providers with a valid record
    (fixture records are authenticated by definition) and None (AUTH_UNVERIFIED) for everything else."""
    from uri_harness_adapters import default_registry
    factory = adapters_factory or default_registry
    rows, executables, bindings, exe_of, levels = [], {}, {}, {}, {}
    for item in load_records(client_root):
        rec = item["record"]
        if rec is None:
            rows.append({"provider": Path(item["path"]).stem, "status": "INVALIDATED", "reason": item["error"], "path": item["path"]})
            continue
        try:
            spec, exe, args = revalidate(rec, allow_fixture=allow_fixture)
        except QualificationError as exc:
            rows.append({"provider": rec["provider"], "status": "INVALIDATED", "reason": exc.code, "detail": exc.detail,
                         "level": rec["level"], "path": item["path"]})
            continue
        executables[rec["provider"]] = [exe, *args]
        exe_of[rec["provider"]], levels[rec["provider"]] = exe, rec["level"]
        bindings[rec["provider"]] = ExecutorBinding(spec=spec, resolved_executable=exe, extra_argv=tuple(args), version=rec["version"],
                                                   executable_sha256=rec["executable_sha256"], qualified_models=tuple(rec["models"]))
        rows.append({"provider": rec["provider"], "status": "QUALIFIED", "reason": None, "level": rec["level"], "models": list(rec["models"]),
                     "executable": exe, "executable_sha256": rec["executable_sha256"], "version": rec["version"],
                     "evidence_sha256": rec["evidence_sha256"], "qualified_at": rec["qualified_at"], "path": item["path"]})

    def probe(harness_id):
        if harness_id not in exe_of:
            return None
        if levels[harness_id] == "FIXTURE_ONLY":
            return True
        if auth_probe is not None:
            return auth_probe(harness_id)
        return native_auth_probe(harness_id, exe_of[harness_id], environ)

    registry = factory(executables, auth_probe=probe)
    for row in rows:
        if row["status"] != "QUALIFIED":
            continue
        p = row["provider"]
        if p not in registry.adapters or registry.adapters[p].refused:
            row.update(status="INVALIDATED", reason="PROVIDER_REFUSED_OR_UNKNOWN")
            bindings.pop(p, None)
            continue
        registry.qualify(p, row["level"], row["evidence_sha256"])
    return ClientComposition(registry=registry, executors=bindings, report=rows, allow_fixture=bool(allow_fixture))
