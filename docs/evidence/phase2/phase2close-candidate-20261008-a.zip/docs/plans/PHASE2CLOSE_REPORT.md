# URI Phase 2 closure report

Date 2026-10-08. Author: Claude (lead implementer and self-auditor; NOT an independent review). Worktree
`C:\Users\cheta\.codex\worktrees\uri-phase2a\uri-agent`, detached at `e8e3b65`, everything uncommitted. Nothing was
committed, pushed, merged, released, frozen, cut over or activated. No login was performed; no credential file was read.
Evidence root `E:` = `C:\Users\cheta\.codex\worktrees\uri-phase2a\evidence\`.

## Verdict

**PHASE 2 TECHNICALLY READY — PHYSICAL/OWNER GATES PENDING** — subject to the regression and review results recorded
in sections H and J (this line is re-confirmed or corrected there; see the correction record at the end).

Not claimed: PHASE 2 ACCEPTED AND QUALIFIED. Human acceptance on the real app, client-profile logins, native
execution inside the worker process (BLOCKED by EXE-1, an owner decision), the physical power-loss campaign, C6 owner
decisions and the C7 cutover remain open (`PHASE2CLOSE_CLOSURE_CHECKLIST.md` section B).

## A. Starting point (verified, not assumed)

* Round-7 accepted candidate `E:phase2ops-candidate-20261008-r6.zip` re-hashed: `9a0be52c...affb50a` (matches).
* Live tree vs its manifest before any closure change: 117 tree files, 116 byte-identical; the one difference is
  `docs/plans/PHASE2OPS_REPORT.md` (the acceptance record appended after the candidate was cut).
* Frozen Phase 1 checkpoint `31a34dcb...efeb98cf7`: hash and byte-identity re-verified by `tests/phase2a/test_frozen_core.py`
  inside every Phase 2 run and by `scripts/phase2close_acceptance.py preflight` (`E:phase2close\acceptance_preflight.json`).
* Recoverable checkpoint before high-risk changes: the round-7 zip itself (immutable, outside the tree).

## B. Acceptance criteria (set before implementation)

1. Each change traces requirement -> implementation -> test (failing on the incoming code where a defect is claimed)
   -> evidence -> review -> status.
2. No frozen Phase 1 file changes; no accepted Phase 2 property weakens; any changed accepted test is disclosed.
3. Every gate rerun on the final tree, sequentially, by one chain that fails loudly (`scripts/phase2close_chain.py`).
4. Physical and owner gates are prepared, never marked passed.
5. Uncertainty that cannot be removed is stated.

## C. Technical closure: findings and repairs

| ID | Finding | Evidence of the defect | Repair | Tests | Status |
|---|---|---|---|---|---|
| LOG-3 (Codex r7, Low) | refusal logger joined every error-body chunk before truncating | negative control on the r6 file: tracemalloc peak 4,209,676 B for a 4 MiB body | bounded `bytearray`, at most `BODY_CAP` = 4096 bytes kept (`refusal_log.py`) | `test_log3_error_body_retention_is_bounded_whatever_the_chunking` (peak < 1 MiB, pass-through intact, split code found, non-bytes body safe) | IMPLEMENTED, TESTED |
| VAL-1 (open since r3) | historical single HTTP 403 on the approval POST, turn left `approval_required` v0 | **Mechanism established.** `paired_coordinator.py:303` stamps `issued_at = int(clock())`; after the `_authority` callback, `client_execution_control.py:77` refuses unless `issued_at == int(clock())`; a second boundary in between -> `TICKET_CLOCK_OR_GENERATION`, re-raised as `ClientControlError(..., 403)` (`paired_coordinator.py:314-316`) before `ClientService.act` bumps the version (`client_service.py:256-261`). Reproduced deterministically with clock injection (no frozen file changed): 403 `{"detail": "TICKET_CLOCK_OR_GENERATION"}`, server turn `approval_required` at the same version = the VAL-1 signature. Control: same injection without the crossing completes. Window measured in-process: 0.000547 s (~0.05 % per approval; larger under load). Other 403 sources reviewed (`TURN_SCOPE`, `SESSION_SCOPE`, `REQUEST_BINDING`, `CLIENT_BINDING`, `SERVER_BINDING`, `PRINCIPAL_BINDING`): all depend on inputs that are constant for the worker. **Residual uncertainty:** the 2026-10-07 instance itself cannot be attributed (no refusal code was logged then); this is the only 403 path found whose inputs vary between identical requests. | `ExecutionController._decide`: ONE resend of the same approval, only if the error is `SERVER_REFUSED:HTTP_403` or `...TICKET_CLOCK_OR_GENERATION`, no cancel requested, the record shows no ticket/task, and the server's own status shows `approval_required` at the approved version and session. A second refusal -> `failed` / `APPROVAL_REFUSED_NOT_APPLIED:<code>` (was `uncertain`), released (CAP-1). UI explains it (`sx-approval-not-applied`). | `tests/phase2ops/test_val1_clock_boundary.py` (6): reproduction, control, window, one-crossing absorbed -> `completed`, precondition refusals (version moved, state moved, other session, progress, server down), seam rules (never a third call, never for a denial, other codes, cancel) | IMPLEMENTED, TESTED |
| CAP-1 (new) | a worker-abandoned `approval_required` turn held server capacity: frozen limits are one active turn per (client, session) and four per server (`client_service.py:169-174`), 15 min idle expiry | probe on the incoming code: after a proposal-digest mismatch the same session got `SERVER_REFUSED:TURN_CAPACITY`, and after four abandoned cards a FRESH session was refused too (whole server blocked) | `SupervisedWorkerService.release_turn/release_pending` post the frozen server's own cancel route (version-checked; the server never relabels a dispatched turn) on: digest mismatch (`execution_begin`, `turn_decide`), malformed decide, VAL-1 final refusal, `close`, stdin EOF | `tests/phase2ops/test_capacity_release.py` (7, incl. stale entry refused `TURN_TERMINAL`/`VERSION_CONFLICT` and server-down reported not raised), `test_worker_process.py::test_cap1_close_and_stdin_eof_release_pending_cards_over_real_frames` (REAL processes) | IMPLEMENTED, TESTED |
| ISO-1 (new, security) | the worker's sanitized client profile did not isolate Codex: Codex 0.158.0 resolves the Windows profile itself | live, read-only: `codex login status` with only USERPROFILE/HOME/APPDATA/LOCALAPPDATA pointed at a client profile -> "Logged in using ChatGPT" (the owner's global login); with `CODEX_HOME` = client profile -> "Not logged in". Found because the closure's own `qualify` step first wrote a NATIVE_QUALIFIED record under the owner's login; that record was VOIDED (moved to `VOIDED_qualification\`, correction in the campaign file), not deleted. | `qualification.client_cli_homes(root)` -> `CODEX_HOME=<client_root>/home/.codex`; the supervised worker sets it at start; `worker-instance.json` records `cli_homes_pinned`; `qualify` uses the same pins | `tests/phase2close/test_iso1_cli_home.py` (3, incl. LIVE leak-and-pin observation and a REAL worker process) | IMPLEMENTED, TESTED |
| EXE-1 (new) | native execution inside the worker process cannot start Codex: the sanitized PATH (venv, System32, git) makes `codex.CMD` fail with `"node" is not recognized`; real worker `harness_discover` -> `NOT_INSTALLED` | observed 2026-10-08 (`claude.CMD --version` works under the same PATH) | NOT repaired: every fix widens what the worker may launch. Options A-D in `PHASE2CLOSE_C7_READINESS.md` section 4 (recommended A: pin `node.exe` in the record) | — | BLOCKED (owner decision) |

Execution / cancellation / recovery / qualification edge cases reviewed beyond these: restart reconciliation of
`queued` records (kept conservative `uncertain`; not changed, no evidence of harm), cancel during the VAL-1 resend
window (resend refused when cancel requested; tested), release of a turn that moved (refused by the server; tested).

## D. Chat and supervised execution (C6 decision 2)

Recommendation, options and the no-decision part: `PHASE2CLOSE_C6_CHAT_INTEGRATION.md`. Recommended option B (Chat
hands an UNSENT draft of the user's own message to the supervised screen); target D; C not before the paired runtime
serves Chat's attachments and model selector. Implemented and tested without the decision: `TaskHandoff`,
`SupervisedExecutionScreen(draft:)`, `SupervisedExecutionEntry.open(context, draft:)` (3 widget tests + 1 VAL-1 display
test). Chat itself is unchanged. Status: AWAITING OWNER DECISION.

## E. Physical acceptance readiness

`PHASE2CLOSE_PHYSICAL_ACCEPTANCE_RUNBOOK.md` (gates PA-1..PA-12) and `scripts/phase2close_acceptance.py`
(preflight / provision / qualify / record / collect). Verified here: preflight `ready_for_session: true`; provision
created `work\c1\acceptance-20261008-045345` (port 18300 range, opt-in file, harness grant); `qualify` fails closed
without a client-profile login (`persisted: false`). Power loss: `scripts/phase2close_powerloss_harness.py`
(guest/host/verify/simulate) implements `PHASE2A_POWER_LOSS_TEST_PLAN.md`; SIMULATED plumbing 3/3 and the test suite
pass; this PC has no Hyper-V cmdlets, so the campaign needs an owner-provided VM. All PA gates: PENDING (PA-10 BLOCKED).

## F. C7 readiness

`PHASE2CLOSE_C7_READINESS.md`: NOT READY. Gates 1-2 MET (Phase 1), 3 and 9 PARTIAL, 4/5/8 NOT MET, 6/10 not
authorized/requested, 7 procedure only; Phase 2 additions P2-1..P2-8 (incl. EXE-1 and the reconciliation of the
`_V1` development line, which is 62 commits past `e8e3b65`).

## G. UI readiness

`docs/architecture/PHASE2CLOSE_UI_READINESS.md`: what exists on each development line, readiness of each target
experience, a presentation-state contract for the Orb derived only from authoritative state, the interfaces the next
phase can rely on, reusable patterns to extract, dependency order. No screen was redesigned.

## H. Regression (final tree, sequential chain `scripts/phase2close_chain.py`)

Filled from `E:phase2close\run4\chain_summary.json` (see the record appended below). Runs 1-3 were aborted by the
orchestrator (tree edited while running) and are kept with `ABORTED.txt`; they are not evidence.

## I. Development ledger

`docs/plans/URI_DEVELOPMENT_TODO.md` (new; supersedes the per-slice ledgers) and `PHASE2CLOSE_CLOSURE_CHECKLIST.md`.

## J. Independent review

Mandate `E:phase2close_review\MANDATE_round1.md`; result appended below.

## K. Files changed (vs the round-7 candidate) and frozen boundary

Changed: `uri_supervisor_bridge/{refusal_log,execution,worker_service,qualification}.py`,
`scripts/run_uri_supervised_worker.py`, `scripts/phase2d_regression.py` (adds `tests/phase2close`),
`tests/phase2a/test_frozen_core.py` (ALLOWED_NEW closure globs), `tests/phase2ops/{test_refusal_log,test_worker_process}.py`,
`tests/phase2d/{test_worker_service,test_worker_process}.py` (**accepted assertions changed for CAP-1**: the dropped
turn is now `cancelled` instead of `approval_required`, and the same session continues instead of `TURN_CAPACITY`;
both say so inline), `uri_ui/lib/screens/tasks/supervised_execution_screen.dart`,
`uri_ui/test/supervised_execution_screen_test.dart`, `docs/architecture/PHASE2OPS_UI_OPERATIONS.md` (superseding
notes appended), `docs/plans/PHASE2OPS_REPORT.md` (round-7 acceptance record, pre-existing).
New: `uri_ui/lib/services/task_handoff.dart`; `tests/phase2close/{__init__,test_iso1_cli_home,test_powerloss_harness}.py`;
`tests/phase2ops/{test_val1_clock_boundary,test_capacity_release}.py`;
`scripts/phase2close_{chain,acceptance,powerloss_harness,checkpoint}.py`; `docs/plans/PHASE2CLOSE_{REPORT,C6_CHAT_INTEGRATION,C7_READINESS,PHYSICAL_ACCEPTANCE_RUNBOOK,CLOSURE_CHECKLIST}.md`;
`docs/architecture/PHASE2CLOSE_UI_READINESS.md`; `docs/plans/URI_DEVELOPMENT_TODO.md`.
Frozen Phase 1 checkpoint files changed: none. Tracked (Phase 1) files: same modified set as before the closure.
Candidate archive and hashes: appended below.

## Record H: regression results on the final tree (2026-10-08)

Chain `scripts/phase2close_chain.py`, sequential, `E:phase2close\run4\` (+ native rerun `run4b\`). ORCHESTRATOR-PRODUCED.

| Gate | Result | Baseline (round 7) |
|---|---|---|
| Phase 2 (`tests/phase2a..2d, phase2ops, phase2close`) | **439 passed, 2 skipped, 0 failed** (379 s) | 415 / 2 |
| Phase 1 authority | **134 passed** | 134 |
| Phase 1 full (Phase 2 excluded) | **2675 passed, 12 skipped, 11 failed**, failure IDs identical to the round-7 log (`SAME_FAILURE_SET: true`) | 2675 / 12 / 11 |
| Residue | none planted | — |
| Flutter (whole `uri_ui/test`) | **195 passed, 2 skipped** ("All tests passed!") | 191 / 2 |
| Live Dart -> real worker -> real server | **10/10**; server logs present, 0 `CLIENT_REFUSAL` lines | 10/10 |
| Native Codex (in-process composition, owner shell login, NOT the worker process) | lifecycle `completed/SETTLED_VERIFIED`; mid-run cancel `uncertain/CANCELLED_AFTER_DISPATCH`, executor `DEAD` (run4 and run4b) | same |

Correction inside the chain: run4 ended `CHAIN_FAILED` only because the native gate's parser read the report JSON
instead of the native script's summary line (the run's own output, `run4\native_codex_stdout.txt`, shows the passing
outcomes). The parser was repaired and the native gate rerun alone (`run4b`, `ALL_PASS`); `run4\CORRECTION.txt` records
it. The parser change touches only `scripts/phase2close_chain.py`, which no test imports. Runs 1-3: aborted, not evidence.

Candidate cut before this record was appended: `E:phase2close-candidate-20261008.zip` (`8982c9f8...ad7777`), superseded
before review by the `-a` candidate below (same tree plus this record).
