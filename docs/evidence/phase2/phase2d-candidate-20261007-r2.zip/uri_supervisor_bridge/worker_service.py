"""Phase 2D worker-side service: the frozen worker protocol, served by the SupervisedTurnRunner.

Same commands and envelopes as the frozen `TurnService` (`turn_start`, `turn_intent`, `turn_decide`), so the
frozen UI client (`uri_ui/lib/services/paired_runtime.dart`) could drive it unchanged, plus two strict additions:

  * `turn_decide` MAY carry `approval_digest`: when present it must equal the digest of the approval request the
    worker showed for that turn; a mismatch drops the pending turn and refuses (`APPROVAL_DIGEST_MISMATCH`). A UI
    that echoes the digest it displayed therefore cannot approve a turn whose arguments changed underneath it. The
    worker still binds the approval to its own pending record either way (UI is never the authority).
  * `turn_cancel {turn_id}`: explicit withdrawal of a pending (not yet dispatched) turn. It is sent to the server as
    a denial, so nothing is ever executed for it. There is no mid-run cancel over this single-threaded protocol;
    the bridge's `cancel()` exists for an owning composition that runs the worker loop in a thread, and worker death
    propagates through the kill-on-close job (Phase 2A/2C evidence).

Pending state is memory-only, exactly as in the frozen service: a worker restart or reconnect drops every pending
turn (fail closed, `TURN_NOT_PENDING`), and the frozen server's own guards (`INTENT_EXECUTION_UNCERTAIN`,
`INTENT_ALREADY_EXECUTED`, duplicate operation ids) prevent a second execution of the same work.
"""
from __future__ import annotations

from uri_core.client_runtime.turn_runner import TurnError

from .runner import SupervisedTurnService

COMMAND_SCHEMAS = {
    "turn_start": ({"command", "session_id", "text", "reasoning"},),
    "turn_intent": ({"command", "session_id", "text", "reasoning", "intent_decision"},),
    "turn_decide": ({"command", "turn_id", "approve"}, {"command", "turn_id", "approve", "approval_digest"}),
    "turn_cancel": ({"command", "turn_id"},),
}


class SupervisedWorkerService(SupervisedTurnService):
    def handle(self, kind, command):
        shapes = COMMAND_SCHEMAS.get(kind)
        if shapes is None or set(command) not in shapes:
            raise TurnError("COMMAND_SCHEMA")
        if kind == "turn_cancel":
            entry = self.pending.pop(command["turn_id"], None)
            if entry is None:
                raise TurnError("TURN_NOT_PENDING")
            text, session, reasoning, turn = entry
            return self._public(self._runner().decide(text, session, reasoning, turn, False))
        if kind == "turn_decide":
            turn_id = command["turn_id"]
            if not isinstance(turn_id, str) or not isinstance(command["approve"], bool):
                self.pending.pop(turn_id, None) if isinstance(turn_id, str) else None
                raise TurnError("TURN_NOT_PENDING")
            if "approval_digest" in command:
                entry = self.pending.get(turn_id)
                shown = ((entry[3].get("approval_request") or {}).get("approval_digest")) if entry else None
                if entry is None or not isinstance(command["approval_digest"], str) or command["approval_digest"] != shown:
                    self.pending.pop(turn_id, None)
                    raise TurnError("APPROVAL_DIGEST_MISMATCH" if entry is not None else "TURN_NOT_PENDING")
                command = {k: v for k, v in command.items() if k != "approval_digest"}
        return super().handle(kind, command)
