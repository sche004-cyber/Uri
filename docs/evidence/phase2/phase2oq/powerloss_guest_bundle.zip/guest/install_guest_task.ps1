# URI power-loss GUEST installer. Run INSIDE the throwaway VM only, as the auto-logon user, in an elevated PowerShell.
param(
    [switch]$IAmInsideTheThrowawayVM,
    [string]$Python = "C:\Python313\python.exe",
    [string]$Ledger = "D:\pl\ledger.db",
    [string]$HostAddress = "10.0.2.2",
    [int]$Port = 47710,
    [ValidateSet("FULL", "NORMAL")][string]$Synchronous = "FULL"
)
if (-not $IAmInsideTheThrowawayVM) { throw "Refused: pass -IAmInsideTheThrowawayVM. Never install this on a real PC." }
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$harness = Join-Path $root "scripts\phase2close_powerloss_harness.py"
$arguments = "-I -B `"$harness`" guest --ledger `"$Ledger`" --host $HostAddress --port $Port --synchronous $Synchronous"
$action = New-ScheduledTaskAction -Execute $Python -Argument $arguments -WorkingDirectory $root
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
Register-ScheduledTask -TaskName "URI-PowerLoss-Guest" -Action $action -Trigger $trigger -RunLevel Limited -Force | Out-Null
Write-Output "Installed: URI-PowerLoss-Guest ($Synchronous) -> $HostAddress`:$Port, ledger $Ledger"
